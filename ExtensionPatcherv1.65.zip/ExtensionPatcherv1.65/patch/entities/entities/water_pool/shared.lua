ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName    = "Water Pool"
ENT.Category 	 = ""
ENT.Author       = "TheZombers / Jn"
ENT.Spawnable    = false