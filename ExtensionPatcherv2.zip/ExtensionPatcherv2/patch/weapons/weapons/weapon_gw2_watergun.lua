SWEP.PrintName = "Water Gun"
    
SWEP.Author = "Mee / Jn" 
SWEP.Purpose = "shoot water man"
SWEP.Instructions = "just left click"
SWEP.Category = "gwater2" 
SWEP.DrawAmmo       = false
SWEP.DrawCrosshair	= true
SWEP.DrawWeaponInfoBox = false

SWEP.Spawnable = true --Must be true
SWEP.AdminOnly = false

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.Weight = 1

SWEP.Primary.ClipSize      = -1
SWEP.Primary.DefaultClip   = -1
SWEP.Primary.Automatic     = true
SWEP.Primary.Ammo          = "none"
SWEP.Primary.Delay = 0

SWEP.Base = "weapon_base"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo		= "none"
SWEP.Secondary.Delay = 0

SWEP.ViewModelFlip		= false
SWEP.ViewModelFOV		= 60
SWEP.ViewModel			= "models/weapons/c_watergun.mdl" 
SWEP.WorldModel			= "models/weapons/w_watergun.mdl"
SWEP.UseHands           = false

local r = GetConVar("gwater2_r")
local g = GetConVar("gwater2_g")
local b = GetConVar("gwater2_b")

local function fuckgarry(w, s)
	if SERVER then 
		if game.SinglePlayer() then 
			w:CallOnClient(s) 
		end
		return true
	end
	return IsFirstTimePredicted()
end


function SWEP:PrimaryAttack()
	--self:SetNextPrimaryFire(CurTime() + 1/60)
	if fuckgarry(self, "PrimaryAttack") then return end

	local owner = self:GetOwner()
	local forward = owner:EyeAngles():Forward()
	local mat = Matrix()
	mat:SetScale(Vector(1, 1, 1) * gwater2["density"])
	mat:SetAngles(owner:EyeAngles() + Angle(90, 0, 0))
	mat:SetTranslation(owner:EyePos() + forward * 20 * gwater2.solver:GetParameter("fluid_rest_distance"))
	
	gwater2.solver:AddCylinder(mat, Vector(gwater2["size"], gwater2["size"], 1), {vel = forward * gwater2["forward_velocity"]})
end

function SWEP:SecondaryAttack()
	if fuckgarry(self, "SecondaryAttack") then return end

	local owner = self:GetOwner()
	local forward = owner:EyeAngles():Forward()

	gwater2.solver:AddSphere(gwater2.quick_matrix(owner:EyePos() + forward * 40 * gwater2.solver:GetParameter("fluid_rest_distance")), 20, {vel = forward * 100})
end

function SWEP:Reload()
	if fuckgarry(self, "Reload") then return end
	
	gwater2.solver:Reset()
end

if SERVER then return end

function SWEP:DrawHUD()
	surface.DrawCircle(ScrW() / 2, ScrH() / 2, gwater2["size"] * gwater2["density"] * 4 * 10, 255, 255, 255, 255)
	draw.DrawText("Left-Click to Spawn Particles", "CloseCaption_Normal", ScrW() * 0.99, ScrH() * 0.75, color_white, TEXT_ALIGN_RIGHT)
	draw.DrawText("Right-Click to Spawn a Sphere", "CloseCaption_Normal", ScrW() * 0.99, ScrH() * 0.78, color_white, TEXT_ALIGN_RIGHT)
	draw.DrawText("Reload to Remove All", "CloseCaption_Normal", ScrW() * 0.99, ScrH() * 0.81, color_white, TEXT_ALIGN_RIGHT)
end

local function format_int(i)
	return tostring(i):reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end

-- visual counter on gun
function SWEP:PostDrawViewModel(vm, weapon, ply)
	local pos, ang = vm:GetBonePosition(0)
	if !pos or !ang then return end

	pos = pos + ang:Right() * -15
	pos = pos + ang:Forward() * 1.435
	pos = pos + ang:Up() * -4.1
	ang:RotateAroundAxis(ang:Forward(), 90)
	ang:RotateAroundAxis(ply:EyeAngles():Forward(), 90)
	ang:RotateAroundAxis(ply:EyeAngles():Up(), -10.1)
	ang:RotateAroundAxis(ply:EyeAngles():Right(), -20)
	cam.Start3D2D(pos, ang, 0.011)
		local options = gwater2.options
		local text = "Water Particles: " .. format_int(gwater2.solver:GetActiveParticles()) .. "/" .. format_int(gwater2.solver:GetMaxParticles())
		local text2 = "Foam Particles: " .. format_int(gwater2.solver:GetActiveDiffuse()) .. "/" .. format_int(gwater2.solver:GetMaxDiffuseParticles())
		draw.RoundedBox(0, -90, -112, 50, 230, Color(100,100,100,100))
		draw.RoundedBox(0, -90, 118, 50, Lerp(gwater2.solver:GetActiveParticles() / gwater2.solver:GetMaxParticles(), 0, -230), Color(tonumber(r:GetString()), tonumber(g:GetString()), tonumber(b:GetString())))
		draw.RoundedBox(0, -34, -112, 50, 230, Color(100,100,100,100))
		draw.RoundedBox(0, -34, 118, 50, Lerp(gwater2.solver:GetActiveDiffuse() / gwater2.solver:GetMaxDiffuseParticles(), 0, -230), Color(255,255,255))
	cam.End3D2D()

end

--[[ -- Benchmarking stuff (ignore)
local avg = 0
local line = 0
local lines = {}
surface.SetDrawColor(0, 255, 0, 255)
avg = avg + (RealFrameTime() - avg) * 0.01

lines[line] = -(6 / avg) + 1080
for i = 0, 1920 do

	if !lines[i - 1] or !lines[i] then continue end
	surface.DrawLine(i * 1, lines[i - 1], i * 1 + 1, lines[i])
end


line = (line + 1) % 1920]]