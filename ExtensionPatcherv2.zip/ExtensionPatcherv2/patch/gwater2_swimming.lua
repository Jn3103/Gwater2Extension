
local GWATER2_PARTICLES_TO_SWIM = 30
local GWATER2_PARTICLES_TO_STOP_SOUND = 10

-- swim code provided by kodya (with permission)
local gravity_convar = GetConVar("sv_gravity")
CreateConVar("gwater2_splashsound", "Normal", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_deadly", "0", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_swimspeed", "2", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_swimfriction", "1", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_swimbuoyancy", "0.5", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_drowntime", "4", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_drownparticles", "60", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_drowndamage", "0.25", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_multiplyparticles", "20", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_multiplywalk", "1", FCVAR_REPLICATED, "idk")
CreateConVar("gwater2_multiplyjump", "1", FCVAR_REPLICATED, "idk")
local function in_water(ply) 
	if ply:OnGround() then return false end
	return ply.GWATER2_CONTACTS and ply.GWATER2_CONTACTS >= GWATER2_PARTICLES_TO_SWIM
end
local function in_stop_water(ply)
	return ply.GWATER2_CONTACTS and ply.GWATER2_CONTACTS >= GWATER2_PARTICLES_TO_STOP_SOUND
end

local function in_any_water(ply)
	if ply.GWATER2_CONTACTS == nil then return false end
	return ply.GWATER2_CONTACTS >= 1
end

local function playsplash(ply)
	selectsound = GetConVar("gwater2_splashsound"):GetString()
	if selectsound == "Not even a splash" then
		ply:EmitSound("confirm.mp3")
	elseif selectsound == "Air" then

	elseif selectsound == "Glue" then
		ply:EmitSound("glue.mp3")
	elseif selectsound == "poison.ogg" then
		ply:EmitSound("poison.mp3")
		ply:KillSilent()
	elseif true then
		ply:EmitSound("Physics.WaterSplash")
	end
end

hook.Add("CalcMainActivity", "gwater2_swimming", function(ply)
	if !in_water(ply) or ply:InVehicle() then return end
	return ACT_MP_SWIM, -1
end)

hook.Add("Move", "gwater2_swimming", function(ply, move)
	if !in_water(ply) then return end

	local vel = move:GetVelocity()
	local ang = move:GetMoveAngles()

	local acel =
	(ang:Forward() * move:GetForwardSpeed()) +
	(ang:Right() * move:GetSideSpeed()) +
	(ang:Up() * move:GetUpSpeed())

	local aceldir = acel:GetNormalized()
	local acelspeed = math.min(acel:Length(), ply:GetMaxSpeed())
	acel = aceldir * acelspeed * 2

	if bit.band(move:GetButtons(), IN_JUMP) ~= 0 then
		acel.z = acel.z + ply:GetMaxSpeed()
	end

	vel = vel + acel * FrameTime()
	vel = vel * (1 - FrameTime() * 2)

	local pgrav = ply:GetGravity() == 0 and 1 or ply:GetGravity()
	local gravity = pgrav * gravity_convar:GetFloat() * 0.5
	vel.z = vel.z + FrameTime() * gravity

	move:SetVelocity(vel * 0.99)
end)

hook.Add("FinishMove", "gwater2_swimming", function(ply, move)
	if !in_water(ply) then return end
	local vel = move:GetVelocity()
	local pgrav = ply:GetGravity() == 0 and 1 or ply:GetGravity()
	local gravity = pgrav * gravity_convar:GetFloat() * 0.5

	vel.z = vel.z + FrameTime() * gravity
	move:SetVelocity(vel)
end)

-- cancel fall damage when in water
hook.Add("GetFallDamage", "gwater2_swimming", function(ply, speed)
	if !ply.GWATER2_CONTACTS or ply.GWATER2_CONTACTS < GWATER2_PARTICLES_TO_SWIM then return end

	playsplash(ply)
	return 0
end)

hook.Add("Think", "awifh", function()
	local ply = player.GetByID(1)
	if !ply:IsValid() then return end
	local in_water_nofloor = ply.GWATER2_CONTACTS and ply.GWATER2_CONTACTS >= tonumber(GetConVar("gwater2_drownparticles"):GetString())
	local in_water_any = ply.GWATER2_CONTACTS and ply.GWATER2_CONTACTS >= tonumber(GetConVar("gwater2_multiplyparticles"):GetString())


	if GetConVar("gwater2_deadly"):GetString() == "1" and player.GetByID(1):Alive() and in_any_water(player.GetByID(1)) and SERVER then
		player.GetByID(1):TakeDamage(1, Entity(1), Entity(1))
	end

	if in_water_nofloor and SERVER then
		underwatertime = underwatertime + FrameTime()
		if underwatertime > tonumber(GetConVar("gwater2_drowntime"):GetString()) then
			player.GetByID(1):TakeDamage(tonumber(GetConVar("gwater2_drowndamage"):GetString()), Entity(1), Entity(1))
		end
	end

	if not in_water_nofloor and SERVER then
		underwatertime = 0
	end

	if in_water_any then
		ply:SetWalkSpeed((160 * tonumber(GetConVar("gwater2_multiplywalk"):GetString())) + 1)
		ply:SetRunSpeed(((240 * tonumber(GetConVar("gwater2_multiplywalk"):GetString()))) + 1)
		ply:SetJumpPower(200 * tonumber(GetConVar("gwater2_multiplyjump"):GetString()))
	else
		ply:SetWalkSpeed(160)
		ply:SetRunSpeed(240)
		ply:SetJumpPower(200)
	end
end)

return in_water