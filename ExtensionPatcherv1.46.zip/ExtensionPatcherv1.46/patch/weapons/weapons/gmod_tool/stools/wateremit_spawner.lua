TOOL.Category = "GWater2"
TOOL.Name = "Water Emitter"
TOOL.Command		= nil
TOOL.ConfigName		= ""

TOOL.Information = {
	{ name = "left", stage = 1 },
}



function TOOL:GetPlacementPosition(tr)
	if not tr then tr = self:GetOwner():GetEyeTrace() end
	if not tr.Hit then return false end

	return (tr.HitPos + tr.HitNormal * (self:GetOwner():GetInfoNum(5, 1) + 1)), rotatedAng
end

if (CLIENT) then
	language.Add("Tool.wateremit_spawner.name", "Water Emitter")
	language.Add("Tool.wateremit_spawner.desc", "Creates Water Emitters")
	language.Add("Tool.wateremit_spawner.left", "Left Click: Spawn Emitter")

	--emitterxsize = CreateClientConVar("wateremit_x", "3", false, true, "Sets the size of the emitter along the X axis", 1, 20)
	--emitterysize = CreateClientConVar("wateremit_y", "3", false, true, "Sets the size of the emitter along the Y axis", 1, 20)
	--emitterzsize = CreateClientConVar("wateremit_z", "3", false, true, "Sets the size of the emitter along the Z axis", 1, 20)
	--emitterspace = CreateClientConVar("wateremit_space", "10", false, true, "Sets the particle size of the emitter (RECOMMENDED: SET TO WATER RADIUS", 1, 100)
	wateremitheight = CreateClientConVar("wateremit_height", "4", false, true, "Sets the height of the emitter", 1, 250)

	function TOOL.BuildCPanel(panel)
		panel:AddControl("label", {
			text = "Creates Water Emitters",
		})
		--panel:NumSlider("Emitter Size X", "wateremit_x", 1, 20, 3)
		--panel:NumSlider("Emitter Size Y", "wateremit_y", 1, 20, 3)
		--panel:NumSlider("Emitter Size Z", "wateremit_z", 1, 20, 3)
		--panel:NumSlider("Emitter Spacing", "wateremit_space", 1, 100, 10)
		panel:NumSlider("Emitter Height", "wateremit_height", 1, 250, 1)
	end


elseif (SERVER) then
	function TOOL:Deploy()
		self:SetStage(1)
	end

	function TOOL:LeftClick(trace)
			local ply = self:GetOwner()
			local hitpos = ply:GetEyeTrace().HitPos
			local ent = ents.Create("water_emitter")
			local pos = hitpos + Vector(0, 0, self:GetOwner():GetInfoNum("wateremit_height", 100))
			if not pos then return false end

			ent:SetPos(pos)
			ent:Spawn()
			self:SetStage(1)

			cleanup.Add(self:GetOwner(), "props", ent)
        	undo.Create("Water Emitter")
        	    undo.AddEntity(ent)
            undo.SetPlayer(self:GetOwner())
        	undo.Finish()
		return true
	end
end