include("shared.lua")

-- Client-side draw function for the entity
function ENT:Draw()
    --self:DrawModel() -- Draws the model of the entity. This function is called every frame.

    local size = Vector(1.5, 1.5, 1.5) * 10

    render.DrawWireframeBox(self:GetPos(), Angle(), -size, size, Color(0, 255, 0, 255), true)
end

function ENT:Think()
    if activesp then
    	local entityPos = self:GetPos()
    	gwater2.solver:AddCube(entityPos + Vector(VectorRand(-1, 1), VectorRand(-1, 1), VectorRand(-1, 1)), Vector(0, 0, -20), Vector(3, 3, 3), 10)
    	self:NextThink(CurTime()+0.05)
   	return true
    end
end