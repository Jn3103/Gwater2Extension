ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName    = "Water Emitter"
ENT.Category 	 = ""
ENT.Author       = "TheZombers"
ENT.Spawnable    = false