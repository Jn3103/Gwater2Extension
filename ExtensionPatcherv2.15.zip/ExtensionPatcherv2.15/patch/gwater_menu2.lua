AddCSLuaFile()

if SERVER or !gwater2 then return end
activesp = true

local color1 = Color(32,72,90)
local color2 = Color(35,140,148)

-- im probably never finishing this

--    - jn

local menuaccent = Color(187, 245, 255)
local menusecondary = Color(0, 0, 0)
local menubackground = Color(0, 0, 0)
local menutext = Color(255, 255, 255)
local menubackground = Color(0, 0, 0, 100)
local menulabelbackground = Color(0, 0, 0, 150)
local menuoutline = Color(255, 255, 255)
local menupopupbackground = Color(0, 0, 0, 200)
local menubuttonshovered = Color(0, 44, 139, 207)
local menubuttons = Color(0, 0, 0, 100)

function createpreset2(sliders, options)
	preset = ""
	presetcolor = sliders["Color"]:GetColor().r .. " " .. sliders["Color"]:GetColor().g .. " " .. sliders["Color"]:GetColor().b .. " " .. sliders["Color"]:GetColor().a
	buttonpressed = true
	for key, value in pairs(sliders) do
		keyst = tostring(key)
		if keyst == "Cohesion" or keyst == "Adhesion" or keyst == "Viscosity" or keyst == "Surface Tension" or keyst == "Fluid Rest Distance" or keyst == "Color" then
			if keyst == "Color" then
				if preset == "" then
					if presetcolor == "209 237 255 25" then
						preset = preset .. keyst .. ":"
					else
						preset = preset .. keyst .. ":" .. presetcolor
					end
				else
					if presetcolor == "209 237 255 25" then
						preset = preset .. "/" .. keyst .. ":"
					else
						preset = preset .. "/" .. keyst .. ":" .. presetcolor
					end
				end
			else
				if preset == "" then
					if value:GetValue() == tonumber(options[keyst]["default"]) then
						preset = preset .. keyst .. ":"
					else
						preset = preset .. keyst .. ":" .. value:GetValue()
					end
				else
					if value:GetValue() == tonumber(options[keyst]["default"]) then
						preset = preset .. "/" .. keyst .. ":"
					else
						preset = preset .. "/" .. keyst .. ":" .. value:GetValue()
					end
				end
			end
		else
			if value:GetValue() ~= tonumber(options[keyst]["default"]) then
				if preset == "" then
					preset = preset .. keyst .. ":" .. value:GetValue()
				else
					preset = preset .. "/" .. keyst .. ":" .. value:GetValue()
				end
			end
		end
		
	end
	local Reflectance = tonumber(GetConVar("gwater2_reflectance"):GetString())
	local SwimSpeed = tonumber(GetConVar("gwater2_swimspeed"):GetString())
	local SwimFriction = tonumber(GetConVar("gwater2_swimfriction"):GetString())
	local SwimBuoyancy = tonumber(GetConVar("gwater2_swimbuoyancy"):GetString())
	local DrownTime = tonumber(GetConVar("gwater2_drowntime"):GetString())
	local DrownParticles = tonumber(GetConVar("gwater2_drownparticles"):GetString())
	local DrownDamage = tonumber(GetConVar("gwater2_drowndamage"):GetString())
	local Iterations = gwater2.solver:GetParameter("iterations")
	local Substeps = gwater2.solver:GetParameter("substeps")
	local MultiplyParticles = tonumber(GetConVar("gwater2_multiplyparticles"):GetString())
	local MultiplyWalk = tonumber(GetConVar("gwater2_multiplywalk"):GetString())
	local MultiplyJump = tonumber(GetConVar("gwater2_multiplyjump"):GetString())
	if Reflectance ~= 0.666 then
		preset = preset .. "/" .. "Reflectance" .. ":" .. Reflectance
	end
	if SwimSpeed ~= 2 then
		preset = preset .. "/" .. "SwimSpeed" .. ":" .. SwimSpeed
	end
	if SwimFriction ~= 1 then
		preset = preset .. "/" .. "SwimFriction" .. ":" .. SwimFriction
	end
	if SwimBuoyancy ~= 0.5 then
		preset = preset .. "/" .. "SwimBuoyancy" .. ":" .. SwimBuoyancy
	end
	if DrownTime ~= 4 then
		preset = preset .. "/" .. "DrownTime" .. ":" .. DrownTime
	end
	if DrownParticles ~= 60 then
		preset = preset .. "/" .. "DrownParticles" .. ":" .. DrownParticles
	end
	if DrownDamage ~= 0.25 then
		preset = preset .. "/" .. "DrownDamage" .. ":" .. DrownDamage
	end
	if Iterations ~= 3 then
		preset = preset .. "/" .. "Iterations" .. ":" .. Iterations
	end
	if Substeps ~= 3 then
		preset = preset .. "/" .. "Substeps" .. ":" .. Substeps
	end
	if MultiplyParticles ~= 20 then
		preset = preset .. "/" .. "MultiplyParticles" .. ":" .. MultiplyParticles
	end
	if MultiplyWalk ~= 1 then
		preset = preset .. "/" .. "MultiplyWalk" .. ":" .. MultiplyWalk
	end
	if MultiplyJump ~= 1 then
		preset = preset .. "/" .. "MultiplyJump" .. ":" .. MultiplyJump
	end
	return preset
end

function parsepreset(params, sliders, options, data)
	for i, v in pairs(sliders) do
		if i == "Color" then
			v:SetColor(options[i].default)
		else
			v:SetValue(options[i].default)
		end
	end
	for _, param in ipairs(params) do
		local key, val = unpack(string.Split(param, ":"))
		if val == "" then val = tostring(options[key].default) end
		if key == "Color" then
			sliders[key]:SetColor(string.ToColor(val))
		elseif key == "Reflectance" then
			RunConsoleCommand("gwater2_reflectance", tostring(val))
		elseif key == "SwimSpeed" then
			RunConsoleCommand("gwater2_swimspeed", tostring(val))
		elseif key == "SwimFriction" then
			RunConsoleCommand("gwater2_swimfriction", tostring(val))
		elseif key == "SwimBuoyancy" then
			RunConsoleCommand("gwater2_swimbuoyancy", tostring(val))
		elseif key == "DrownTime" then
			RunConsoleCommand("gwater2_drowntime", tostring(val))
		elseif key == "DrownParticles" then
			RunConsoleCommand("gwater2_drownparticles", tostring(val))
		elseif key == "DrownDamage" then
			RunConsoleCommand("gwater2_swimdamage", tostring(val))
		elseif key == "Iterations" then
			gwater2.solver:SetParameter("iterations", val)
		elseif key == "Substeps" then
			gwater2.solver:SetParameter("substeps", val)
		elseif key == "MultiplyParticles" then
			RunConsoleCommand("gwater2_multiplyparticles", tostring(val))
		elseif key == "MultiplyWalk" then
			RunConsoleCommand("gwater2_multiplywalk", tostring(val))
		elseif key == "MultiplyJump" then
			RunConsoleCommand("gwater2_multiplyjump", tostring(val))
		else
			sliders[key]:SetValue(tonumber(val))
		end
	end
	if string.Replace(data, "Reflectance", "s") == data then
		RunConsoleCommand("gwater2_reflectance", "0.666")
	end
	if string.Replace(data, "SwimSpeed", "s") == data then
		RunConsoleCommand("gwater2_swimspeed", "2")
	end
	if string.Replace(data, "SwimFriction", "s") == data then
		RunConsoleCommand("gwater2_swimfriction", "1")
	end
	if string.Replace(data, "SwimBuoyancy", "s") == data then
		RunConsoleCommand("gwater2_swimbuoyancy", "0.5")
	end
	if string.Replace(data, "SwimBuoyancy", "s") == data then
		RunConsoleCommand("gwater2_swimbuoyancy", "0.5")
	end
	if string.Replace(data, "DrownTime", "s") == data then
		RunConsoleCommand("gwater2_drowntime", "4")
	end
	if string.Replace(data, "DrownParticles", "s") == data then
		RunConsoleCommand("gwater2_drownparticles", "60")
	end
	if string.Replace(data, "DrownDamage", "s") == data then
		RunConsoleCommand("gwater2_drowndamage", "0.25")
	end
	if string.Replace(data, "Iterations", "s") == data then
		gwater2.solver:SetParameter("iterations", 3)
	end
	if string.Replace(data, "Substeps", "s") == data then
		gwater2.solver:SetParameter("substeps", 3)
	end
	if string.Replace(data, "MultiplyParticles", "s") == data then
		RunConsoleCommand("gwater2_multiplyparticles", "20")
	end
	if string.Replace(data, "MultiplyWalk", "s") == data then
		RunConsoleCommand("gwater2_multiplywalk", "1")
	end
	if string.Replace(data, "MultiplyJump", "s") == data then
		RunConsoleCommand("gwater2_multiplyjump", "1")
	end
end

-- *Ehem*
-- BEHOLD. THE GWATER MENU CODE
-- THIS MY FRIEND.. IS THE SINGLE WORST PIECE OF CODE I HAVE EVER WRITTEN
-- PLEASE NOTE THAT: 
	-- SOURCE VGUI IS ABSOLUTELY DOODOO
	-- THE GMOD INTERFACE IS ABSOLULTELY DOODOO
	-- HALF OF THIS CODE WAS WRITTEN AT 3 AM
-- THANK YOU FOR COMING TO MY TED TALK
-- jn note: i made it even worse, youre welcome
local function format_int(i)
	return tostring(i):reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end

local function extension_welcome(version)
	local frame = vgui.Create("DFrame", mainFrame)
	frame:SetSize(ScrW(),ScrH())
	frame:SetPos(0,0)
	frame:SetTitle("gwater2 (v" .. version .. ")")
	frame:MakePopup()
	frame:SetAlpha(0)
	frame:AlphaTo(255, 2.975, 0, function()
		local savepreset = vgui.Create("DButton", frame)
		local buttonpressed2 = false
		function savepreset:Paint(w, h)
			if buttonpressed2 then
				surface.SetDrawColor(9, 255, 0, 141)
			elseif savepreset:IsHovered() then
				surface.SetDrawColor(0, 139, 19, 207)
			else
				surface.SetDrawColor(0, 95, 21, 100)
			end
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
		savepreset:SetText("Done")
		savepreset:SetSize(200, 20)
		savepreset:SetPos((ScrW() / 2) - 100, ScrH() / 1.5)
		savepreset:SetTextColor(Color(255, 255, 255))
		function savepreset:DoClick()
			buttonpressed2 = false
			frame:Close()
			file.Write("extensionused.txt", "funny")
			surface.PlaySound("buttons/button15.wav")
		end
	end)
	frame:SetBackgroundBlur(true)
	frame:SetScreenLock(true)
	surface.PlaySound("extension.mp3")
	function frame:Paint(w, h)
		-- Blur background
		render.UpdateScreenEffectTexture()
		render.BlurRenderTarget(render.GetScreenEffectTexture(), (frame:GetAlpha() / 255) * 10, (frame:GetAlpha() / 255) * 10, 50)
		render.SetRenderTarget()
		render.DrawScreenQuad()

		-- dark background around 2d water sim
		surface.SetDrawColor(menupopupbackground)
		surface.DrawRect(0, 0, w, h)

		-- main outline
		surface.SetDrawColor(menuoutline)
		surface.DrawOutlinedRect(0, 0, w, h)

		if frame:GetAlpha() == 255 then

			draw.DrawText(
			[[
			This screen means you patched extension correctly
			Congrats!


			Now do some stuff with extension
			Maybe break the fluids?
			Create Presets?
			Explore the preset store?
			Or just play around with the new settings
			Its up to you
			
			If you got this window after patching v2.10, this is normal
			This window will not pop up again after pressing Done
			If you for some reason want to see this screen again (maybe because of on update), you can use the extension_welcome command
			
			   Enjoy]]
			, "GWater2Title", ScrW() / 2.3, ScrH() / 3, color_white, TEXT_ALIGN_CENTER)
			

		end
	
		draw.DrawText("Welcome", "GWater2BigTitle", ScrW() / 2, ScrH() / 4.5, color1, TEXT_ALIGN_CENTER)
		draw.DrawText("Welcome", "GWater2BigTitle", ScrW() / 2.01, ScrH() / 4.52, color2, TEXT_ALIGN_CENTER)
	
	end

	local imageex = vgui.Create("DImage", frame)
	imageex:SetPos(ScrW() / 3.8, ScrH() / 16)
	imageex:SetSize(4096 / 4, 1028 / 4)
	imageex:SetImage("extension/Welcome.png")
end

local version = "0.5b (Extension v2.15)"

local options = {
	solver = FlexSolver(1000),
	tab = CreateClientConVar("gwater2_tab", "1", true),
	blur_passes = CreateClientConVar("gwater2_blur_passes", "3", true),
	absorption = CreateClientConVar("gwater2_absorption", "1", true),
	depth_fix = CreateClientConVar("gwater2_depth_fix", "1", true),
	menu_key = CreateClientConVar("gwater2_menukey", KEY_G, true),
	color = Color(255, 255, 255, 255),
	parameter_tab_header = "Parameter Tab",
	parameter_tab_text = "This tab is where you can change how the water interacts with itself and the environment.\n\nHover over a parameter to reveal its functionality.",
	adv_parameter_tab_header = "Adv. Parameter Tab",
	adv_parameter_tab_text = "This tab is similar to the parameter tab but includes settings which aren't as obvious.\n\nHover over a parameter to reveal its functionality.",
	visuals_tab_header = "Visuals Tab",
	visuals_tab_text = "This tab controls what the fluid looks like.\n\nHover over a parameter to reveal its functionality",
	about_tab_header = "About Tab",
	about_tab_text = "On each tab, this area will contain useful information.\n\nFor example:\nClicking anywhere outside the menu, or re-pressing the menu button will close it.\n\nMake sure to read this area!",
	performance_tab_header = "Performance Tab",
	performance_tab_text = "This tab has options which can help and alter your performance.\n\nEach option is colored between green and red to indicate its performance hit.\n\nAll parameters directly impact the GPU.",
	patron_tab_header = "Patron Tab",
	patron_tab_text = "This tab has a list of all my patrons.\n\nThe list is sorted in alphabetical order.\n\nIt will be updated routinely until release.",
	watergun_tab_header = "Water Gun Tab",
	watergun_tab_text = "These options affect the water pistol.\n\nThis tab is temporary and will be removed in 0.6b.",

	-- Physics Parameters
	Cohesion = {text = "Controls how well particles hold together.\n\nHigher values make the fluid more solid/rigid, while lower values make it more fluid and loose."},
	Adhesion = {text = "Controls how well particles stick to surfaces.\n\nNote that this specific parameter doesn't reflect changes in the preview very well and may need to be viewed externally."},
	Gravity = {text = "Controls how strongly fluid is pulled down. This value is measured in meters per second.\n\nNote that the default source gravity is -15.24 which is NOT the same as Earths gravity of -9.81."},
	Viscosity = {text = "Controls how much particles resist movement.\n\nHigher values look more like honey or syrup, while lower values look like water or oil."},
	Radius = {text = "Controls the size of each particle.\n\nIn the preview it is clamped to 15 to avoid weirdness.\n\nRadius is measured in source units and is the same for all particles."},
	["Surface Tension"] = {text = "Controls how strongly particles minimize surface area.\n\nThis parameter tends to make particles behave oddly if set too high\n\nUsually bundled with cohesion."},
	["Fluid Rest Distance"] = {text = "Controls the collision distance between particles.\n\nHigher values cause more lumpy liquids while lower values cause smoother liquids"},
	["Timescale"] = {text = "Sets the speed of the simulation.\n\nNote that some parameters like cohesion and surface tension may behave differently due to smaller or larger compute times"},
	["Collision Distance"] = {text = "Controls the collision distance between particles and objects.\n\nNote that a lower collision distance will cause particles to clip through objects more often."},
	["Vorticity Confinement"] = {text = "Increases the vorticity effect by applying rotational forces to particles.\n\nThis exists because air pressure cannot be efficiently simulated."},
	["Dynamic Friction"] = {text = "Controls the amount of friction particles receive on surfaces.\n\nCauses Adhesion to behave weirdly when set to 0."},
	
	-- Visual Parameters
	Color = {text = "Controls the color of the fluid.\n\nThe alpha (transparency) channel controls the amount of color absorbsion.\n\nAn alpha value of 255 (maxxed) makes the fluid opaque."},
	["Anisotropy Min"] = {text = "Controls the minimum size that particles can be."}, 
	["Anisotropy Max"] = {text = "Controls the maximum size that particles are allowed to stretch between particles."},
	["Anisotropy Scale"] = {text = "Controls the size of stretching between particles.\n\nMaking this value zero will turn off stretching."},
	["Diffuse Threshold"] = {text = "Controls the amount of force required to make a bubble/foam particle."},
	["Diffuse Lifetime"] = {text = "Controls how long bubbles/foam particles last after being created.\n\nThis is affected by the Timescale parameter.\n\nSetting this to zero will spawn no diffuse particles"},

	Iterations = {text = "Controls how many times the physics solver attempts to converge to a solution per substep.\n\nMedium performance impact."},
	Substeps = {text = "Controls the number of physics steps done per tick.\n\nNote that parameters may not be properly tuned for different substeps!\n\nMedium-High performance impact."},
	["Blur Passes"] = {text = "Controls the number of blur passes done per frame. More passes creates a smoother water surface. Zero passes will do no blurring.\n\nLow performance impact."},
	["Absorption"] = {text = "Enables absorption of light over distance inside of fluid.\n\n(more depth = darker color)\n\nMedium performance impact."},
	["Depth Fix"] = {text = "Makes particles appear spherical instead of flat, creating a cleaner and smoother water surface.\n\nCauses shader overdraw.\n\nMedium-High performance impact."},
	["Particle Limit"] = {text = "USE THIS PARAMETER AT YOUR OWN RISK.\n\nChanges the limit of particles.\n\nNote that a higher limit will negatively impact performance even with the same number of particles spawned."},
	["Reaction Forces"] = {text = "0 = No reaction forces\n\n1 = Simple reaction forces. (Swimming)\n\n2 = Full reaction forces (Water can move props).\n\nNote that reaction forces only work with 'New Solver' on."},
	
	["Size"] = {text = "Size of the box the particles spawn in"},
	["Density"] = {text = "Density of particles.\n Controls how far apart they are"},
	["Forward Velocity"] = {text = "The forward facing velocity the particles spawn with"},

	["Force Multiplier"] = {text = "Determines the amount of force which is applied to props by water."},
	["Force Buoyancy"] = {text = "Buoyant force which is applied to props in water.\n\nThe implementation is by no means accurate and probably should not be used for prop boats."},
	["Force Dampening"] = {text = "Dampening force applied to props.\n\nHelps a little bit if props tend to bounce on the water surface."},
}

hook.Add("PostGamemodeLoaded", "loadstuff", function() -- i hate vgui.Create failed to create the VGUI component (DPanel), this is a goofy ah way to do it, idc	
	local frameinfo2 = vgui.Create("DPanel")
	frameinfo2:SetSize(200, 50)
	frameinfo2:SetBackgroundColor(color2)
	local frameinfo = vgui.Create("DPanel")
	frameinfo:SetSize(190, 40)
	frameinfo:SetPos(5,5)
	frameinfo:SetBackgroundColor(color1)
	local particles = vgui.Create("Label", frameinfo)
	particles:SetSize( 400, 10 )
	local foam = vgui.Create("Label", frameinfo)
	foam:SetSize( 400, 10 )
	foam:SetPos(0,10)
	foam:SetText("Foam Particles: " .. format_int(gwater2.solver:GetActiveDiffuse()) .. "/" .. format_int(gwater2.solver:GetMaxDiffuseParticles()))
	local fps = vgui.Create("Label", frameinfo)
	fps:SetSize( 400, 10 )
	fps:SetPos(0,20)
	fps:SetText("FPS: " ..  1 / FrameTime())
	local fpsr = vgui.Create("Label", frameinfo)
	fpsr:SetSize( 400, 10 )
	fpsr:SetPos(0,30)
	fpsr:SetText("Rounded FPS: " ..  math.floor(1 / FrameTime() * 100) / 100)
	particles:SetText("Water Particles: " .. format_int(gwater2.solver:GetActiveParticles()) .. "/" .. format_int(gwater2.solver:GetMaxParticles()))
	function frameinfo2:PaintOver()
		particles:SetText("Water Particles: " .. format_int(gwater2.solver:GetActiveParticles()) .. "/" .. format_int(gwater2.solver:GetMaxParticles()))
		foam:SetText("Foam Particles: " .. format_int(gwater2.solver:GetActiveDiffuse()) .. "/" .. format_int(gwater2.solver:GetMaxDiffuseParticles()))
		fps:SetText("FPS: " ..  (1 / FrameTime() * 100) / 100)
		fpsr:SetText("Rounded FPS: " ..  math.floor(1 / FrameTime() * 100) / 100)
	end

	timer.Simple(2, function()
		if file.Read("extensionused.txt") == nil then
			extension_welcome(version)
		end
	end)
end)

local finalpass = Material("gwater2/finalpass")
local volumetric = Material("gwater2/volumetric")
local normals = Material("gwater2/normals")
local cloth = Material("gwater2/cloth")

-- garry, sincerely... fuck you
timer.Simple(0, function() 
	volumetric:SetFloat("$alpha", options.absorption:GetBool() and 0.125 or 0)
	normals:SetInt("$depthfix", options.depth_fix:GetBool() and 1 or 0)
	options.color = Color(finalpass:GetVector4D("$color2"))
end)

options.solver:SetParameter("gravity", 15.24)	-- flip gravity because y axis positive is down
options.solver:SetParameter("static_friction", 0)	-- stop adhesion sticking to front and back walls
options.solver:SetParameter("dynamic_friction", 0)	-- ^
options.solver:SetParameter("diffuse_threshold", math.huge)	-- no diffuse particles allowed in preview
options.solver:SetParameter("max_acceleration", 200)	-- stops explosions, makes play more fun

-- designs for tabs and frames
local function draw_tabs(self, w, h)
	if h != 20 then
		surface.SetDrawColor(0, 80, 255, 230)
		surface.DrawRect(2,0,w - 4,h - 8)
	else
		draw.RoundedBox(0, 2, 0, w - 4, 20, Color( 27, 27, 27, 230))
	end
	surface.SetDrawColor(menuoutline)
	surface.DrawOutlinedRect(2, 0, w - 4, 21, 1)
end

local function draw_label(self, w, h) 
	surface.SetDrawColor(menulabelbackground)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(menuoutline)
	surface.DrawOutlinedRect(0, 0, w, h)
end

surface.CreateFont("GWater2Param", {
    font = "Space Mono", 
    extended = false,
    size = 20,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
})

surface.CreateFont("GWater2Title", {
    font = "coolvetica", 
    extended = false,
    size = 24,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
})

surface.CreateFont("GWater2BigTitle", {
    font = "coolvetica", 
    extended = false,
    size = 100,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
})

-- Smooth scrollbar (code from Spanky)
local GFScrollPanel = {}
AccessorFunc(GFScrollPanel, "scrolldistance", "ScrollDistance", FORCE_NUMBER)
function GFScrollPanel:Init()
    self:SetScrollDistance(32)
    local scrollPanel = self

    local vbar = self:GetVBar()
    function vbar:OnMouseWheeled( dlta )
        if not self:IsVisible() then return false end
        -- We return true if the scrollbar changed.
        -- If it didn't, we feed the mousehweeling to the parent panel
        if self.CurrentScroll == nil then self.CurrentScroll = self:GetScroll() end
        self.CurrentScroll = math.Clamp(self.CurrentScroll + (dlta * -scrollPanel:GetScrollDistance()), 0, self.CanvasSize)
        self:AnimateTo(self.CurrentScroll, 0.05, 0, 0.1)
        return self:AddScroll( dlta * -2 )
    end
    function vbar:OnMouseReleased()
        self.CurrentScroll = self:GetScroll()

        self.Dragging = false
        self.DraggingCanvas = nil
        self:MouseCapture( false )
    
        self.btnGrip.Depressed = false
    end
end
vgui.Register("GF_ScrollPanel", GFScrollPanel, "DScrollPanel")

local function set_gwater_parameter(option, val)

	-- nondirect options (eg. parameter scales based on radius)
	if gwater2[option] then
		gwater2[option] = val
		if option == "surface_tension" then	-- hack hack hack! this parameter scales based on radius
			local r1 = val / gwater2.solver:GetParameter("radius")^4	-- cant think of a name for this variable rn
			local r2 = val / math.min(gwater2.solver:GetParameter("radius"), 15)^4
			gwater2.solver:SetParameter(option, r1)
			options.solver:SetParameter(option, r2)
		elseif option == "fluid_rest_distance" or option == "collision_distance" or option == "solid_rest_distance" then -- hack hack hack! this parameter scales based on radius
			local r1 = val * gwater2.solver:GetParameter("radius")
			local r2 = val * math.min(gwater2.solver:GetParameter("radius"), 15)
			gwater2.solver:SetParameter(option, r1)
			options.solver:SetParameter(option, r2)
		elseif option == "cohesion" then	-- also scales by radius
			local r1 = math.min(val / gwater2.solver:GetParameter("radius") * 10, 1)
			gwater2.solver:SetParameter(option, r1)
			options.solver:SetParameter(option, r1)
		end
		return
	end

	gwater2.solver:SetParameter(option, val)

	if option == "gravity" then val = -val end	-- hack hack hack! y coordinate is considered down in screenspace!
	if option == "radius" then 					-- hack hack hack! radius needs to edit multiple parameters!
		gwater2.solver:SetParameter("surface_tension", gwater2["surface_tension"] / val^4)	-- literally no idea why this is a power of 4
		gwater2.solver:SetParameter("fluid_rest_distance", val * gwater2["fluid_rest_distance"])
		gwater2.solver:SetParameter("solid_rest_distance", val * gwater2["solid_rest_distance"])
		gwater2.solver:SetParameter("collision_distance", val * gwater2["collision_distance"])
		gwater2.solver:SetParameter("cohesion", math.min(gwater2["cohesion"] / val * 10, 1))
		
		if val > 15 then val = 15 end	-- explody
		options.solver:SetParameter("surface_tension", gwater2["surface_tension"] / val^4)
		options.solver:SetParameter("fluid_rest_distance", val * gwater2["fluid_rest_distance"])
		options.solver:SetParameter("solid_rest_distance", val * gwater2["solid_rest_distance"])
		options.solver:SetParameter("collision_distance", val * gwater2["collision_distance"])
		options.solver:SetParameter("cohesion", math.min(gwater2["cohesion"] / val * 10, 1))
	end

	if option != "diffuse_threshold" and option != "dynamic_friction" then -- hack hack hack! fluid preview doesn't use diffuse particles
		options.solver:SetParameter(option, val)
	end
end

-- some helper functions
local function create_slider(self, text, min, max, decimals, dock, length, out, func)
	length = length or 450
	out = out or -90

	local option = string.lower(text)
	option = string.gsub(option, " ", "_")
	local param = gwater2[option] or gwater2.solver:GetParameter(option)

	if options[text] then
		options[text].default = options[text].default or param
	else
		print("Undefined parameter '" .. text .. "'!") 
	end
	
	local label = vgui.Create("DLabel", self)
	label:SetPos(10, dock)
	label:SetSize(200, 20)
	label:SetText(text)
	label:SetColor(menutext)
	label:SetTextColor(menutext)
	label:SetFont("GWater2Param")

	local slider = vgui.Create("DNumSlider", self)
	slider:SetPos(out, dock)
	slider:SetSize(length, 20)
	slider:SetMinMax(min, max)
	slider:SetValue(param)
	slider:SetDecimals(decimals)
	
	-- rounds slider to nearest decimal
	function slider:OnValueChanged(val)
		if decimals == 0 and val != math.Round(val, decimals) then
			self:SetValue(math.Round(val, decimals))
			return
		end
		if func then func(val) end
		set_gwater_parameter(option, val)
	end

	local button = vgui.Create("DButton", self)
	button:SetPos(355, dock)
	button:SetSize(20, 20)
	button:SetText("")
	button:SetImage("icon16/arrow_refresh.png")
	button.Paint = nil

	function button:DoClick()
		slider:SetValue(options[text].default)
		surface.PlaySound("buttons/button15.wav")
	end

	return label, slider
end

local function create_slider_convar(self, decimals, dock, convar, name, default, low, high, length)
	length = length or 450
	local out = -90

	local label = vgui.Create("DLabel", self)
	label:SetPos(10, dock)
	label:SetSize(200, 20)
	label:SetText(name)
	label:SetColor(Color(255, 255, 255))
	label:SetFont("GWater2Param")

	local slider = vgui.Create("DNumSlider", self)
	slider:SetPos(out, dock)
	slider:SetSize(length, 20)
	slider:SetMinMax(low, high)
	slider:SetValue(tonumber(GetConVar(convar):GetString()))
	slider:SetDecimals(decimals)
	
	-- rounds slider to nearest decimal
	function slider:OnValueChanged(val)
		if decimals == 0 and val != math.Round(val, decimals) then
			self:SetValue(math.Round(val, decimals))
			return
		end
		RunConsoleCommand(convar, tostring(val))
	end

	local button = vgui.Create("DButton", self)
	button:SetPos(355, dock)
	button:SetSize(20, 20)
	button:SetText("")
	button:SetImage("icon16/arrow_refresh.png")
	button.Paint = nil

	function button:DoClick()
		slider:SetValue(default)
		EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 ) 
	end

	return slider
end


local function create_label(self, text, subtext, dock, size)
	local label = vgui.Create("DLabel", self)
	label:SetPos(0, dock or 0)
	label:SetSize(385, size or 329)
	label:SetText("")

	function label:Paint(w, h)
		draw_label(self, w, h)
		
		draw.DrawText(text, "GWater2Title", 6, 6, menusecondary, TEXT_ALIGN_LEFT)
		draw.DrawText(text, "GWater2Title", 5, 5, menuaccent, TEXT_ALIGN_LEFT)
		draw.DrawText(subtext, "DermaDefault", 5, 24, menuaccent, TEXT_ALIGN_LEFT)
	end
	return label
end

-- color picker
local function copy_color(c) return Color(c.r, c.g, c.b, c.a) end
local function create_picker(self, text, dock)
	local label = vgui.Create("DLabel", self)
	label:SetPos(9, dock)
	label:SetSize(100, 100)
	label:SetFont("GWater2Param")
	label:SetText(text)
	label:SetColor(Color(255, 255, 255))
	label:SetContentAlignment(7)

	if options[text] then 
		options[text].default = options[text].default or copy_color(options.color)	-- copy, dont reference
	else
		print("Undefined parameter '" .. text .. "'!") 
	end

	local mixer = vgui.Create("DColorMixer", self)
	mixer:SetPos(65, dock + 5)
	mixer:SetSize(276, 110)
	mixer:SetPalette(false)
	mixer:SetLabel()
	mixer:SetAlphaBar(true)
	mixer:SetWangs(true)

	for k, wang in pairs(mixer:GetChildren()[3]:GetChildren()) do
		for k, arrow in pairs(wang:GetChildren()) do
			function arrow:Paint(w, h)
				surface.SetDrawColor(menuoutline)
				
				if k == 1 then
					surface.DrawLine(w * 0.5, 4, w * 0.5 - 4, 8)
					surface.DrawLine(w * 0.5, 4, w * 0.5 + 4, 8)
				else
					surface.DrawLine(w * 0.5, h - 3, w * 0.5 - 4, h - 7)
					surface.DrawLine(w * 0.5, h - 3, w * 0.5 + 4, h - 7)
				end
			end
		end

		-- this probably could be mathematically created but im too lazy to think of a way to do this properly
		local colors = {
			Color(255, 0, 0),
			Color(0, 255, 0),
			Color(0, 0, 255),
			Color(255, 255, 255)
		}

		function wang:Paint(w, h)
			surface.SetDrawColor(menulabelbackground)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(colors[k])
			surface.DrawOutlinedRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, 50)
			surface.DrawLine(w * 0.5 + 10, 4, w * 0.5 + 10, h - 4)
			local cutoff_start_x, cutoff_start_y = wang:LocalToScreen(0,0)
			local cutoff_end_x, cutoff_end_y = wang:LocalToScreen(w * 0.5 + 10,h)
			render.SetScissorRect(cutoff_start_x, cutoff_start_y, cutoff_end_x, cutoff_end_y, true)
				draw.DrawText(self:GetValue(), "DermaDefault", 5, 3, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
			render.SetScissorRect(cutoff_start_x, cutoff_start_y, cutoff_end_x, cutoff_end_y, false)
		end
	end

	mixer:SetColor(options.color) 
	function mixer:ValueChanged(col)
		options.color = copy_color(col)	-- color returned by ValueChanged doesnt have any metatables
		finalpass:SetVector4D("$color2", col.r, col.g, col.b, col.a)
	end

	local button = vgui.Create("DButton", self)
	button:SetPos(355, dock)
	button:SetText("")
	button:SetSize(20, 20)
	button:SetImage("icon16/arrow_refresh.png")
	button.Paint = nil
	function button:DoClick()
		local copy = copy_color(options[text].default)
		mixer:SetColor(copy)
		surface.PlaySound("buttons/button15.wav")
	end

	return label, mixer
end

local function create_explanation(parent)
	local explanation = vgui.Create("DLabel", parent)
	explanation:SetTextInset(5, 30)
	explanation:SetWrap(true)
	explanation:SetColor(Color(255, 255, 255))
	explanation:SetContentAlignment(7)	-- shove text in top left corner
	explanation:SetFont("GWater2Param")
	explanation:SetSize(175, 329)
	explanation:SetPos(390, 0)

	return explanation
end

--------------- Actual menu code ------------------------------

concommand.Add("extension_welcome", function()
	extension_welcome(version)
end)

local mainFrame = nil
local just_closed = false
concommand.Add("gwater2_menu", function()
	if IsValid(mainFrame) then return end

	--local average_fps = 1 / 60
	local particle_material = CreateMaterial("gwater2_menu_material", "UnlitGeneric", {
		["$basetexture"] = "vgui/circle",
		["$vertexcolor"] = 1,
		["$vertexalpha"] = 1,
		["$ignorez"] = 1
	})

    -- start creating visual design
    mainFrame = vgui.Create("DFrame")
    mainFrame:SetSize(800, 400)
	mainFrame:SetSizable(false)
    mainFrame:Center()
	mainFrame:SetTitle("gwater2 (v" .. version .. ")")
    mainFrame:MakePopup()
	mainFrame:SetScreenLock(true)

	local minimize_btn = mainFrame:GetChildren()[3]
	--minimize_btn:SetMouseInputEnabled(false)
	minimize_btn:SetVisible(false)
	
	local maximize_btn = mainFrame:GetChildren()[2]
	--maximize_btn:SetMouseInputEnabled(false)
	maximize_btn:SetVisible(false)

	local close_btn = mainFrame:GetChildren()[1]
	close_btn:SetVisible(false)

	local new_close_btn = vgui.Create("DButton", mainFrame)
	new_close_btn:SetPos(777, 3)
	new_close_btn:SetSize(20, 20)
	new_close_btn:SetText("")

	function new_close_btn:DoClick()
		mainFrame:Remove()
		--surface.PlaySound("buttons/lightswitch2.wav")
		just_closed = false
	end

	function new_close_btn:Paint(w, h)
		if self:IsHovered() then
			surface.SetDrawColor(255, 0, 0, 127)
			surface.DrawRect(0, 0, w, h)
		end
		surface.SetDrawColor(menuoutline)
		surface.DrawOutlinedRect(0, 0, w, h)
		surface.DrawLine(5, 5, w - 5, h - 5)
		surface.DrawLine(w - 6, 5, 5 - 1, h - 5)
	end

	function mainFrame:Paint(w, h)
		-- dark background around 2d water sim
		surface.SetDrawColor(0, 0, 0, 230)
		surface.DrawRect(0, 0, w, 25)
		surface.SetDrawColor(menubackground)
		surface.DrawRect(0, 25, w, h - 25)

		local x, y = mainFrame:LocalToScreen()
		local radius = options.solver:GetParameter("radius")
		local function exp(v) return Vector(math.exp(v[1]), math.exp(v[2]), math.exp(v[3])) end
		local is_translucent = options.color.a < 255
		surface.SetMaterial(particle_material)
		options.solver:RenderParticles(function(pos)
			local depth = math.max((pos[3] - y) / 390, 0) * 20	-- ranges from 0 to 20 down
			local absorption = is_translucent and exp((options.color:ToVector() - Vector(1, 1, 1)) * options.color.a / 255 * depth) or options.color:ToVector()
			surface.SetDrawColor(absorption[1] * 255, absorption[2] * 255, absorption[3] * 255, 255)
			surface.DrawTexturedRect(pos[1] - x, pos[3] - y, radius, radius)
		end)

		-- 2d simulation
		local mat = Matrix()
		mat:SetTranslation(Vector(x + 60 + math.random(), 0, y + 50))
		options.solver:InitBounds(Vector(x, 0, y + 25), Vector(x + 192, options.solver:GetParameter("radius"), y + 390))
		options.solver:AddCube(mat, Vector(4, 1, 1), {vel = Vector(0, 0, 50)})
		options.solver:Tick(1 / 60)
		
		--average_fps = average_fps + (FrameTime() - average_fps) * 0.01

		-- main outline
		surface.SetDrawColor(menuoutline)
		surface.DrawOutlinedRect(0, 0, w, h)
		surface.DrawOutlinedRect(5, 30, 192, h - 35)

		draw.RoundedBox(5, 36, 35, 125, 30, Color(10, 10, 10, 230))
		draw.DrawText("Fluid Preview", "GWater2Title", 100, 40, color_white, TEXT_ALIGN_CENTER)
	end

	-- close menu if menu button is pressed
	function mainFrame:OnKeyCodePressed(key)
		if key == options.menu_key:GetInt() then
			mainFrame:Remove()
			just_closed = true
		end
	end

	-- menu "center" button
	local button = vgui.Create("DButton", mainFrame)
	button:SetPos(755, 3)
	button:SetSize(20, 20)
	button:SetText("")
	button:SetImage("icon16/anchor.png")
	button.Paint = nil
	function button:DoClick()
		mainFrame:Center()
		surface.PlaySound("buttons/button15.wav")
	end

	input.SetCursorPos(ScrW() / 2 + 20, ScrH() / 2 - 188)

	-- 2d simulation
	options.solver:Reset()

    -- the tabs
    local tabsFrame = vgui.Create("DPanel", mainFrame)
    tabsFrame:SetSize(600, 365)
    tabsFrame:SetPos(200, 30)
    tabsFrame.Paint = nil

	-- explanation area definition
	local explanation
	local explanation_header

	-- used in presets to update menu sliders after selection
	local sliders = {}

    -- the parameter tab, contains settings for the water
    local function parameter_tab(tabs)
        local scrollPanel = vgui.Create("GF_ScrollPanel", tabs)

        local scrollEditTab = tabs:AddSheet("Parameters", scrollPanel, "icon16/cog.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- parameters
		local labels = {}

		create_label(scrollPanel, "Physics Parameters", "These settings directly influence physics.", 0, 270)
		labels[1], sliders["Adhesion"] = create_slider(scrollPanel, "Adhesion", 0, 1, 3, 50)
		labels[2], sliders["Cohesion"] = create_slider(scrollPanel, "Cohesion", 0, 2, 4, 80)
		labels[3], sliders["Radius"] = create_slider(scrollPanel, "Radius", 0.1, 500, 2, 110)
		labels[4], sliders["Gravity"] = create_slider(scrollPanel, "Gravity", -50, 50, 2, 140)
		labels[5], sliders["Viscosity"] = create_slider(scrollPanel, "Viscosity", 0, 100, 2, 170)
		labels[6], sliders["Surface Tension"] = create_slider(scrollPanel, "Surface Tension", 0, 10, 2, 200, 350, 10)
		labels[7], sliders["Timescale"] = create_slider(scrollPanel, "Timescale", 0, 4, 2, 230)

		create_label(scrollPanel, "Advanced Physics Parameters", "More technical settings.", 275, 182)
		labels[8], sliders["Collision Distance"] = create_slider(scrollPanel, "Collision Distance", 0.1, 2, 2, 327, 315, 55)
		labels[9], sliders["Fluid Rest Distance"] = create_slider(scrollPanel, "Fluid Rest Distance", 0.5, 0.8, 2, 357, 315, 55)
		labels[10], sliders["Dynamic Friction"] = create_slider(scrollPanel, "Dynamic Friction", -1, 2, 2, 385, 317, 55)
		labels[11], sliders["Vorticity Confinement"] = create_slider(scrollPanel, "Vorticity Confinement", -500, 500, 0, 417, 300, 75)

		create_label(scrollPanel, "Reaction Force Parameters", "'Reaction Forces' (in performance tab) must be set to 2 for these to work!", 462, 200)
		labels[12], sliders["Force Multiplier"] = create_slider(scrollPanel, "Force Multiplier", 0.001, 10000, 3, 514, 315, 55)
		labels[13], sliders["Force Buoyancy"] = create_slider(scrollPanel, "Force Buoyancy", 0, 50000, 1, 544, 315, 55)
		labels[14], sliders["Force Dampening"] = create_slider(scrollPanel, "Force Dampening", 0, 100, 2, 574, 315, 55)

		
		function scrollPanel:AnimationThink()
			local mousex, mousey = self:LocalCursorPos()
			local text_name = nil
			for _, label in pairs(labels) do
				local x, y = label:GetPos()
				y = y - self:GetVBar():GetScroll()
				local w, h = 345, 22
				if y >= -20 and mousex > x and mousey > y and mousex < x + w and mousey < y + h then
					label:SetColor(Color(177, 255, 154))
					text_name = label:GetText()
				else
					label:SetColor(Color(255, 255, 255))
				end
			end

			if text_name then
				explanation:SetText(options[text_name].text)
				explanation_header = text_name
			else
				explanation:SetText(options.parameter_tab_text)
				explanation_header = options.parameter_tab_header
			end
		end

		local copypreset = vgui.Create("DButton", scrollPanel)
		local buttonpressed = false
		function copypreset:Paint(w, h)
			if buttonpressed then
				surface.SetDrawColor(menubuttonshovered)
			elseif copypreset:IsHovered() then
				surface.SetDrawColor(menubuttonshovered)
			else
				surface.SetDrawColor(menubuttons)
			end
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
		copypreset:SetText("Copy Extension Preset Parameters")
		copypreset:SetSize(175,50)
		copypreset:SetPos(100, 600)
		local colornormal = Color(255,255,255,255)
		local colorhovered = Color(0,27,86)
		local colorpressed = Color(0,80,255,255)
		copypreset:SetTextColor(colornormal)
		function copypreset:OnMousePressed()
			local preset = createpreset2(sliders, options)
			local x, y = mainFrame:GetPos() x = x + 200 y = y + 100
			local frame = vgui.Create("DFrame", mainFrame)
			frame:SetSize(10000,10000)
			frame:SetPos(0,0)
			frame:SetTitle("gwater2 (v" .. version .. ")")
			frame:MakePopup()
			frame:SetBackgroundBlur(true)
			frame:SetScreenLock(true)
			function frame:Paint(w, h)
				-- Blur background
				render.UpdateScreenEffectTexture()
				render.BlurRenderTarget(render.GetScreenEffectTexture(), 5, 5, 1)
				render.SetRenderTarget()
				render.DrawScreenQuad()

				-- dark background around 2d water sim
				surface.SetDrawColor(menupopupbackground)
				surface.DrawRect(0, 0, w, h)

				-- main outline
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h)

				-- from testing it seems each particle is around 0.8kb so you could probably do some math to figure out the memory required and show it here
	
				draw.DrawText("Copy Preset", "GWater2Title", ScrW() / 2, ScrH() / 2.1, color_white, TEXT_ALIGN_CENTER)
				draw.DrawText("Please Set Name", "DermaDefault", ScrW() / 2, ScrH() / 2, color_white, TEXT_ALIGN_CENTER)
			
			end

			local confirm = vgui.Create("DButton", frame)
			confirm:SetPos(ScrW() / 1.9, ScrH() / 1.8)
			confirm:SetText("")
			confirm:SetSize(20, 20)
			confirm:SetImage("icon16/accept.png")
			confirm.Paint = nil
			local name = vgui.Create("DTextEntry", frame)
			name:SetPos(ScrW() / 2.1, ScrH() / 1.9)
			name:SetText("")
			name:SetSize(100, 20)
			name:SetPaintBackground(false)
			name:SetTextColor(colornormal)
			name:SetCursorColor(colornormal)
			function name:PaintOver(w, h)
				if name:IsHovered() then
					surface.SetDrawColor(menubuttonshovered)
				else
					surface.SetDrawColor(menubuttons)
				end
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
			function confirm:DoClick() 
				SetClipboardText(name:GetText() .. ",," .. preset)
				frame:Close()
				buttonpressed = false
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			end

			local deny = vgui.Create("DButton", frame)
			deny:SetPos(ScrW() / 2.1, ScrH() / 1.8)
			deny:SetText("")
			deny:SetSize(20, 20)
			deny:SetImage("icon16/cross.png")
			deny.Paint = nil
			function deny:DoClick() 
				frame:Close()
				buttonpressed = false
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			end

			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
		end
		function copypreset:OnMouseReleased()
			buttonpressed = false
		end

		function presets:ApplySchemeSettings()
			presets:SetFGColor(Color(255, 255, 255))
		end

		function presets:Paint(w, h)
			if presets:IsHovered() then
				surface.SetDrawColor(menubuttonhovered)
			else
				surface.SetDrawColor(0, 0, 0, 100)
			end
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
    end


	-- the parameter tab, contains settings for the water
    local function visuals_tab(tabs)
        local scrollPanel = vgui.Create("GF_ScrollPanel", tabs)

        local scrollEditTab = tabs:AddSheet("Visuals", scrollPanel, "icon16/picture.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- parameters
		local labels = {}
		create_label(scrollPanel, "Visual Parameters", "These settings directly influence visuals.", 0, 475)
		labels[1], sliders["Diffuse Threshold"] = create_slider(scrollPanel, "Diffuse Threshold", 1, 500, 1, 50, 350, 20)
		labels[2], sliders["Diffuse Lifetime"] = create_slider(scrollPanel, "Diffuse Lifetime", 0, 20, 1, 80, 350, 20)
		labels[3], sliders["Anisotropy Scale"] = create_slider(scrollPanel, "Anisotropy Scale", 0, 2, 2, 110, 350, 20)
		labels[4], sliders["Anisotropy Min"] = create_slider(scrollPanel, "Anisotropy Min", 0, 1, 2, 140, 350, 20)
		labels[5], sliders["Anisotropy Max"] = create_slider(scrollPanel, "Anisotropy Max", 0, 2, 2, 170, 350, 20)
		labels[6], sliders["Color"] = create_picker(scrollPanel, "Color", 200)
		
		function scrollPanel:AnimationThink()
			local mousex, mousey = self:LocalCursorPos()
			local text_name = nil
			for _, label in pairs(labels) do
				local x, y = label:GetPos()
				local w, h = 345, 22
				if y >= -20 and mousex > x and mousey > y and mousex < x + w and mousey < y + h then
					label:SetColor(Color(177, 255, 154))
					text_name = label:GetText()
				else
					label:SetColor(Color(255, 255, 255))
				end
			end

			if text_name then
				explanation:SetText(options[text_name].text)
				explanation_header = text_name
			else
				explanation:SetText(options.visuals_tab_text)
				explanation_header = options.visuals_tab_header
			end
		end

		local function create_picker_mats(self, text, dock, mats, default, mat)
			local label = vgui.Create("DLabel", self)
			label:SetPos(9, dock)
			label:SetSize(100, 100)
			label:SetFont("GWater2Param")
			label:SetText(text)
			label:SetColor(Color(255, 255, 255))
			label:SetContentAlignment(7)
		
			local mixer = vgui.Create("DColorMixer", self)
			mixer:SetPos(65, dock + 5)
			mixer:SetSize(276, 110)
			mixer:SetPalette(false)
			mixer:SetLabel()
			mixer:SetAlphaBar(true)
			mixer:SetWangs(true)
		
			for k, wang in pairs(mixer:GetChildren()[3]:GetChildren()) do
				for k, arrow in pairs(wang:GetChildren()) do
					function arrow:Paint(w, h)
						surface.SetDrawColor(255, 255, 255)
						
						if k == 1 then
							surface.DrawLine(w * 0.5, 4, w * 0.5 - 4, 8)
							surface.DrawLine(w * 0.5, 4, w * 0.5 + 4, 8)
						else
							surface.DrawLine(w * 0.5, h - 3, w * 0.5 - 4, h - 7)
							surface.DrawLine(w * 0.5, h - 3, w * 0.5 + 4, h - 7)
						end
					end
				end
		
				-- this probably could be mathematically created but im too lazy to think of a way to do this properly
				local colors = {
					Color(255, 0, 0),
					Color(0, 255, 0),
					Color(0, 0, 255),
					Color(255, 255, 255)
				}
		
				function wang:Paint(w, h)
					surface.SetDrawColor(menulabelbackground)
					surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(colors[k])
					surface.DrawOutlinedRect(0, 0, w, h)
					surface.SetDrawColor(255, 255, 255, 50)
					surface.DrawLine(w * 0.5 + 10, 4, w * 0.5 + 10, h - 4)
					local cutoff_start_x, cutoff_start_y = wang:LocalToScreen(0,0)
					local cutoff_end_x, cutoff_end_y = wang:LocalToScreen(w * 0.5 + 10,h)
					render.SetScissorRect(cutoff_start_x, cutoff_start_y, cutoff_end_x, cutoff_end_y, true)
						draw.DrawText(self:GetValue(), "DermaDefault", 5, 3, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
					render.SetScissorRect(cutoff_start_x, cutoff_start_y, cutoff_end_x, cutoff_end_y, false)
				end
			end
			local colormat = mat:GetVector("$color2")
		
			mixer:SetColor(Color(colormat.x * 255, colormat.y * 255, colormat.z * 255))
			function mixer:ValueChanged(col)	-- color returned by ValueChanged doesnt have any metatables
				for i, v in pairs(mats) do
					if isnumber(v) then return end
					v:SetVector("$color2", Vector(col.r / 255, col.g / 255, col.b / 255))
					v:SetFloat("$alpha", col.a / 255)
				end
			end
		
			local button = vgui.Create("DButton", self)
			button:SetPos(355, dock)
			button:SetText("")
			button:SetSize(20, 20)
			button:SetImage("icon16/arrow_refresh.png")
			button.Paint = nil
			function button:DoClick()
				local copy = default
				mixer:SetColor(copy)
				surface.PlaySound("buttons/button15.wav")
			end
		
			return label, mixer
		end

		local cloths = {Material("gwater2/cloth"), Material("cloth/gw1cloth"), Material("cloth/realisticcloth"), Material("cloth/notexture"), Material("cloth/carpet"), Material("cloth/meetric"), Material("cloth/reflective"), Material("cloth/romania"), Material("cloth/checkerboard"), Material("cloth/drake"), Material("cloth/denmark"), Material("cloth/gay")}
		local clothlabel = vgui.Create("DLabel", scrollPanel)
		clothlabel:SetPos(9, 325)
		clothlabel:SetSize(100, 100)
		clothlabel:SetFont("GWater2Param")
		clothlabel:SetText("Cloth Skin")
		clothlabel:SetColor(Color(255, 255, 255))
		clothlabel:SetContentAlignment(7)
		create_picker_mats(scrollPanel, "Cloth Color", 350, cloths, Color(128, 178, 229, 255), cloth)
		
		local clothskin = vgui.Create("DComboBox", scrollPanel)
		clothskin:SetPos(110, 325)
		clothskin:SetSize(100, 20)
		clothskin:SetText(GetConVar("gwater2_clothskin"):GetString())
		clothskin:AddChoice("One Color", nil, false, "gwater2/cloth")
		clothskin:AddChoice("GW1 Cloth", nil, false, "cloth/gw1cloth")
		clothskin:AddChoice("Realistic", nil, false, "cloth/realisticcloth")
		clothskin:AddChoice("Missing Texture", nil, false, "gwater2/a")
		clothskin:AddChoice("Carpet", nil, false, "cloth/carpet")
		clothskin:AddChoice("Meetric", nil, false, "cloth/meetric")
		clothskin:AddChoice("Reflective", nil, false, "cloth/reflective")
		clothskin:AddChoice("Romania", nil, false, "cloth/romania")
		clothskin:AddChoice("Checkerboard", nil, false, "cloth/checkerboard")
		clothskin:AddChoice("drake.PNG", nil, false, "cloth/drake")
		clothskin:AddChoice("Denmark", nil, false, "cloth/denmark")
		clothskin:AddChoice("Gay", nil, false, "cloth/gay")

		function clothskin:OnSelect(index, value, data)
			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100)
			RunConsoleCommand("gwater2_clothskin", value)
		end

		function clothskin:ApplySchemeSettings()
			clothskin:SetFGColor(menutext)
		end

		function clothskin:OnMenuOpened(pnl)
			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100)
			for k, label in pairs(pnl:GetCanvas():GetChildren()) do
				function label:Paint(w, h)
					if self:IsHovered() then
						surface.SetDrawColor(0,80,255, 60)
						surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(menuoutline)
					surface.DrawOutlinedRect(5, h, w - 10, 0, 1)
				end
				label:SetTextColor(menutext)
			end
			function pnl:Paint(w, h)
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
		end

		function clothskin:Paint(w, h)
			if clothskin:IsMenuOpen() then
				surface.SetDrawColor(0, 80, 255, 60)
			else
				surface.SetDrawColor(0, 0, 0, 100)
			end
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
    end


    local function performance_tab(tabs)
        local scrollPanel = vgui.Create("GF_ScrollPanel", tabs)

        local scrollEditTab = tabs:AddSheet("Performance", scrollPanel, "icon16/application_xp_terminal.png").Tab
		scrollEditTab.Paint = draw_tabs

		local colors = {
			Color(250, 250, 0),
			Color(255, 127, 0),
			Color(127, 255, 0),
			Color(255, 0, 0), 
			Color(255, 0, 0), 
			Color(250, 250, 0),
			Color(255, 127, 0),
		}

		local slider
		local labels = {}
		create_label(scrollPanel, "Performance Settings", "These settings directly influence performance")
		-- create_slider(self, text, min, max, decimals, dock, x_offset, length, label_offset_x, reset_offset_x)
		labels[1] = create_slider(scrollPanel, "Iterations", 1, 10, 0, 50, 410, -50)
		labels[2] = create_slider(scrollPanel, "Substeps", 1, 10, 0, 80, 410, -50)
		labels[3], slider = create_slider(scrollPanel, "Blur Passes", 0, 4, 0, 110, 410, -50, function(val) 
			options.blur_passes:SetInt(val) 
		end) 
		slider:SetValue(options.blur_passes:GetInt())
	
		-- particle limit box
		local label = vgui.Create("DLabel", scrollPanel)
		label:SetPos(10, 140)
		label:SetSize(200, 20)
		label:SetText("Particle Limit")
		label:SetFont("GWater2Param")
		labels[4] = label

		local slider = vgui.Create("DNumSlider", scrollPanel)
		slider:SetPos(10, 140)
		slider:SetSize(322, 20)
		slider:SetMinMax(1, 1000000)
		slider:SetDecimals(0)
		slider:SetValue(gwater2.solver:GetMaxParticles())

		local button = vgui.Create("DButton", scrollPanel)
		button:SetPos(355, 140)
		button:SetText("")
		button:SetSize(20, 20)
		button:SetImage("icon16/arrow_refresh.png")
		button.Paint = nil
		function button:DoClick()
			slider:SetValue(100000)
			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100)
		end

		-- 'confirm' particle limit button. Creates another DFrame
		local button = vgui.Create("DButton", scrollPanel)
		button:SetPos(332, 140)
		button:SetText("")
		button:SetSize(20, 20)
		button:SetImage("icon16/accept.png")
		button.Paint = nil
		function button:DoClick()
			local x, y = mainFrame:GetPos() x = x + 200 y = y + 100
			local frame = vgui.Create("DFrame", mainFrame)
			frame:SetSize(10000,10000)
			frame:SetPos(0,0)
			frame:SetTitle("gwater2 (v" .. version .. ")")
			frame:MakePopup()
			frame:SetBackgroundBlur(true)
			frame:SetScreenLock(true)
			function frame:Paint(w, h)
				-- Blur background
				render.UpdateScreenEffectTexture()
				render.BlurRenderTarget(render.GetScreenEffectTexture(), 5, 5, 1)
				render.SetRenderTarget()
				render.DrawScreenQuad()

				-- dark background around 2d water sim
				surface.SetDrawColor(menupopupbackground)
				surface.DrawRect(0, 0, w, h)

				-- main outline
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h)

				-- from testing it seems each particle is around 0.8kb so you could probably do some math to figure out the memory required and show it here
	
				draw.DrawText("You are about to change the particle limit to \n" .. math.floor(slider:GetValue()) .. ".\nMemory required: " .. math.floor(math.floor(slider:GetValue()) * 0.0008 * 10) / 10 .. "mb", "GWater2Title", ScrW() / 2, ScrH() / 2.3, color_white, TEXT_ALIGN_CENTER)
				draw.DrawText([[This can be dangerous, because all particles must be allocated on the GPU.
DO NOT set the limit to a number higher then you think your computer can handle.
I DO NOT take responsiblity for any hardware damage this may cause]], "DermaDefault", ScrW() / 2, ScrH() / 2, color_white, TEXT_ALIGN_CENTER)
			
			end

			local confirm = vgui.Create("DButton", frame)
			confirm:SetPos(ScrW() / 1.9, ScrH() / 1.8)
			confirm:SetText("")
			confirm:SetSize(20, 20)
			confirm:SetImage("icon16/accept.png")
			confirm.Paint = nil
			function confirm:DoClick() 
				gwater2.solver:Destroy()
				gwater2.solver = FlexSolver(slider:GetValue())
				gwater2.reset_solver(true)
				frame:Close()
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100)
			end

			local deny = vgui.Create("DButton", frame)
			deny:SetPos(ScrW() / 2.1, ScrH() / 1.8)
			deny:SetText("")
			deny:SetSize(20, 20)
			deny:SetImage("icon16/cross.png")
			deny.Paint = nil
			function deny:DoClick() 
				frame:Close()
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100)
			end

			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100)
		end

		labels[5] = create_slider(scrollPanel, "Reaction Forces", 0, 2, 0, 170, 370, -10)

		-- Absorption checkbox & label
		local label = vgui.Create("DLabel", scrollPanel)	
		label:SetPos(10, 200)
		label:SetSize(100, 100)
		label:SetFont("GWater2Param")
		label:SetText("Absorption")
		label:SetContentAlignment(7)
		labels[6] = label

		local box = vgui.Create("DCheckBox", scrollPanel)
		box:SetPos(132, 200)
		box:SetSize(20, 20)
		box:SetChecked(options.absorption:GetBool())
		function box:OnChange(val)
			options.absorption:SetBool(val)
			volumetric:SetFloat("$alpha", val and 0.125 or 0)
		end

		-- Depth fix checkbox & label
		local label = vgui.Create("DLabel", scrollPanel)	
		label:SetPos(10, 230)
		label:SetSize(100, 100)
		label:SetFont("GWater2Param")
		label:SetText("Depth Fix")
		label:SetContentAlignment(7)
		labels[7] = label

		local box = vgui.Create("DCheckBox", scrollPanel)
		box:SetPos(132, 230)
		box:SetSize(20, 20)
		box:SetChecked(options.depth_fix:GetBool())
		function box:OnChange(val)
			options.depth_fix:SetBool(val)
			normals:SetInt("$depthfix", val and 1 or 0)
		end

		-- light up & change explanation area
		function scrollPanel:AnimationThink()
			if !mainFrame:HasFocus() then return end
			local mousex, mousey = self:LocalCursorPos()
			local text_name = nil
			for i, label in pairs(labels) do
				local x, y = label:GetPos()
				y = y - self:GetVBar():GetScroll() - 1
				local w, h = 345, 22
				if y >= -20 and mousex > x and mousey > y and mousex < x + w and mousey < y + h then
					label:SetColor(Color(colors[i].r + 127, colors[i].g + 127, colors[i].b + 127))
					text_name = label:GetText()
				else
					label:SetColor(colors[i])
				end
			end

			if text_name then
				explanation:SetText(options[text_name].text)
				explanation_header = text_name
			else
				explanation:SetText(options.performance_tab_text)
				explanation_header = options.performance_tab_header
			end
		end

    end

	local function about_tab(tabs)
        local scrollPanel = vgui.Create("GF_ScrollPanel", tabs)
        local scrollEditTab = tabs:AddSheet("About", scrollPanel, "icon16/exclamation.png").Tab
		scrollEditTab.Paint = draw_tabs

		local label = vgui.Create("DLabel", scrollPanel)
		label:SetPos(0, 0)
		label:SetSize(383, 820)
		label:SetText([[
			Thank you for downloading gwater2 beta! This menu is the interface that you will be using to control everything about gwater. So get used to it! :D

			Make sure to read the changelog to see what has been updated!

			Changelog (v0.5b):
			- Added cloth to spawnmenu

			- Added black hole to spawnmenu
			
			- Added emitter, and drain entity to spawnmenu

			- Added particle lifetimes (evaporation)

			- Added gravity gun interaction

			- Tweaked absorption, reflection, and phong calculations to be more realistic

			- Tweaked diffuse visuals

			- Tweaked portal gel preset to look more like portal gel

			- Fixed particles not going through objects with 'Disable Collision' on

			- Fixed a majority of particle clipping issues

			- Fixed being able to 'fly' in adhesive liquids

			- General backend code cleanup and API improvements

		]])
		label:SetColor(Color(255, 255, 255))
		label:SetTextInset(5, 30)
		label:SetWrap(true)
		label:SetContentAlignment(7)	-- shove text in top left corner
		label:SetFont("GWater2Param")
		function label:Paint(w, h)
			surface.SetDrawColor(menubackground)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)

			draw.DrawText("Welcome to gwater2! (v" .. version .. ")", "GWater2Title", 6, 6, menusecondary, TEXT_ALIGN_LEFT)
			draw.DrawText("Welcome to gwater2! (v" .. version .. ")", "GWater2Title", 5, 5, menuaccent, TEXT_ALIGN_LEFT)

			explanation:SetText(options.about_tab_text)
			explanation_header = options.about_tab_header
		end
    end

	local function watergun_tab(tabs)
		local scrollPanel = vgui.Create("DScrollPanel", tabs)
		local scrollEditTab = tabs:AddSheet("Water Gun", scrollPanel, "icon16/gun.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- parameters
		local labels = {}
		local label = create_label(scrollPanel, "Water Gun", "Settings for the water pistol.")
		local old = label.Paint
		label.Paint = function(self, x, y)
			old(self, x, y)
			explanation:SetText(options.watergun_tab_text)
			explanation_header = options.watergun_tab_header
		end

		labels[1], sliders["Size"] = create_slider(scrollPanel, "Size", 1, 10, 0, 50, 370, 0)
		labels[2], sliders["Density"] = create_slider(scrollPanel, "Density", 0.5, 5, 1, 80, 370, 0)
		labels[3], sliders["Forward Velocity"] = create_slider(scrollPanel, "Forward Velocity", 0, 300, 0, 110, 370, 0)
		create_slider_convar(scrollPanel, 2, 140, "gwater2_pickforce", "Pick Force", 200, -500, 500) --self, decimals, dock, convar, name, default, low, high, length
		create_slider_convar(scrollPanel, 2, 170, "gwater2_pickrange", "Pick Range", 150, 0, 1000)
		create_slider_convar(scrollPanel, 2, 200, "gwater2_puntforce", "Punt Force", 200, 0, 1000)
		create_slider_convar(scrollPanel, 2, 230, "gwater2_puntrange", "Punt Range", 320, 0, 1000)
	end

	local function patron_tab(tabs)
        local scrollPanel = vgui.Create("DScrollPanel", tabs)
        local scrollEditTab = tabs:AddSheet("Patrons", scrollPanel, "icon16/award_star_gold_3.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- Hi - Xenthio

		-- DONT FORGET TO ADD 'Xenthio' & 'NecrosVideos'
		local patrons = file.Read("gwater2_patrons.lua", "LUA") or "<Failed to load patron data!>"
		local patrons_table = string.Split(patrons, "\n")

		local label = vgui.Create("DLabel", scrollPanel)
		label:SetPos(0, 0)
		label:SetSize(383, math.max(#patrons_table * 20, 1000) + 180)
		label:SetText([[
			Thanks to everyone here who supported me throughout the development of GWater2!
			
			All revenue generated from this project goes directly to my college fund. Thanks so much guys :)
			-----------------------------------------
			]])
		label:SetColor(menutext)
		label:SetTextInset(5, 30)
		label:SetWrap(true)
		label:SetContentAlignment(7)	-- shove text in top left corner
		label:SetFont("GWater2Param")
		function label:Paint(w, h)
			surface.SetDrawColor(menulabelbackground)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)

			draw.DrawText("Patrons", "GWater2Title", 6, 6, menusecondary, TEXT_ALIGN_LEFT)
			draw.DrawText("Patrons", "GWater2Title", 5, 5, menuaccent, TEXT_ALIGN_LEFT)

			local patron_color = Color(171, 255, 163)
			local top = math.max(math.floor((scrollPanel:GetVBar():GetScroll() - 150) / 20), 1)	-- only draw what we see
			for i = top, math.min(top + 20, #patrons_table) do
				draw.DrawText(patrons_table[i], "GWater2Param", 6, 150 + i * 20, patron_color, TEXT_ALIGN_LEFT)
			end

			explanation:SetText(options.patron_tab_text)
			explanation_header = options.patron_tab_header
		end
    end

	function extension_presetpicker(tabs)
		local scrollPanel = vgui.Create("DScrollPanel", tabs)
		local scrollEditTab = tabs:AddSheet("Preset Picker", scrollPanel, "extension/ico logo.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- parameters
		local labels = {}
		local label = create_label(scrollPanel, "Preset Picker", "", 0, 625)
		local old = label.Paint
		label.Paint = function(self, x, y)
			old(self, x, y)
			explanation:SetText([[Preset Picker
			
			Made by Jn]])
			explanation_header = "Extension"
		end

		local prei = 1
		local coloralways = Color(255,255,255,255)
		local allpresets = {}

		function createpreset(name, data, showdelete, realdata)
			local button = vgui.Create("DButton")
			button:SetText(name)
			button:SetSize(385, 20)
			button:SetPos(0, (prei + 0.25) * 20)
			button:SetImage("icon16/images.png")
			function button:DoClick()
				local params = string.Split(data, "\n")
				if table.Count(params) == 1 then
					params = string.Split(data, "/")
				end
				parsepreset(params, sliders, options, data)
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			end
			button:SetAlpha(255)
			function button:Paint(w, h)
				if button:IsHovered() then
					surface.SetDrawColor(0, 44, 139, button:GetAlpha() * 0.39215686274)
				else
					surface.SetDrawColor(0, 0, 0, button:GetAlpha() * 0.39215686274)
					button:SetColor(coloralways)
				end

				if button:GetAlpha() == 0 then
					button:Remove()
				end

				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(Color(menuoutline.r, menuoutline.g, menuoutline.b, menuoutline.a * button:GetAlpha() / 255))
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
			prei = prei + 1
			-- button:SetSize(0, 0)
			-- button:SetPos(385 / 2, (prei + 0.25) * 20 / 2)
			-- button:SizeTo(385, 20, 0.5, 0, 0.25)
			-- button:MoveTo(0, (prei - 0.75) * 20, 0.5, 0, 0.25)

			local button3 = vgui.Create("DImageButton", button)
			button3:SetPos(367, 2)
			button3:SetSize(16, 16)
			button3:SetImage("icon16/page_copy.png")
			button3:SetColor(Color(255, 255, 255, button3:GetAlpha()))
			function button3:DoClick()
				if realdata ~= nil then
					SetClipboardText(realdata)
				else
					SetClipboardText(name .. ",," .. string.Replace(data, "\n", "/"))
				end
				surface.PlaySound("buttons/lightswitch2.wav")
			end
			function button3:PaintOver()
				if button3:GetAlpha() == 0 then
					button3:Remove()
				end
			end

			if showdelete == "yes" then
				local button2 = vgui.Create("DImageButton", button)
				button2:SetPos(349, 2)
				button2:SetSize(16, 16)
				button2:SetImage("icon16/image_delete.png")
				button2:SetColor(Color(255, 255, 255, button2:GetAlpha()))
				function button2:PaintOver()
					if button2:GetAlpha() == 0 then
						button2:Remove()
					end
				end
				local frozenprei = prei - 1
				function button2:DoClick()
					surface.PlaySound("buttons/lightswitch2.wav")
					local installed = file.Read("installedpresets.txt", "DATA")
					file.Write("installedpresets.txt", string.Replace(installed, "nextpresetdefinder" .. realdata, ""))
					for i, v in pairs(allpresets) do
						if !v:IsValid() then continue end
						v:Remove()
					end
					generatepresets()
				end
			end

			if showdelete == "yes1" then
				local button2 = vgui.Create("DImageButton", button)
				button2:SetPos(349, 2)
				button2:SetSize(16, 16)
				button2:SetImage("icon16/image_delete.png")
				button2:SetColor(Color(255, 255, 255, button2:GetAlpha()))
				function button2:PaintOver()
					if button2:GetAlpha() == 0 then
						button2:Remove()
					end
				end
				local frozenprei = prei - 1
				function button2:DoClick()
					surface.PlaySound("buttons/lightswitch2.wav")
					local installed = file.Read("importedpresets.txt", "DATA")
					file.Write("importedpresets.txt", string.Replace(installed, "nextpresetdefinder" .. realdata, ""))
					
					timer.Simple(0.5, function()
						for i, v in pairs(allpresets) do
							if i > frozenprei then
								if !v:IsValid() then return end
								local orgy = v:GetY()- 20
								v:MoveTo(0, v:GetY() - 20, 0.5, 0, 0.25, function()
									v:SetPos(0, orgy)
								end)
							end
						end
					end)
					
					button:AlphaTo(0, 0.5, 0)
					button2:AlphaTo(0, 0.5, 0)
					button3:AlphaTo(0, 0.5, 0)
				end
			end

			if showdelete == "yes2" then
				local button2 = vgui.Create("DImageButton", button)
				button2:SetPos(349, 2)
				button2:SetSize(16, 16)
				button2:SetImage("icon16/image_delete.png")
				button2:SetColor(Color(255, 255, 255, button2:GetAlpha()))
				function button2:PaintOver()
					if button2:GetAlpha() == 0 then
						button2:Remove()
					end
				end
				local frozenprei = prei - 1
				function button2:DoClick()
					surface.PlaySound("buttons/lightswitch2.wav")
					local installed = file.Read("savedpresets.txt", "DATA")
					file.Write("savedpresets.txt", string.Replace(installed, "nextpresetdefinder" .. realdata, ""))
					
					timer.Simple(0.5, function()
						for i, v in pairs(allpresets) do
							if i > frozenprei then
								if !v:IsValid() then return end
								local orgy = v:GetY()- 20
								v:MoveTo(0, v:GetY() - 20, 0.5, 0, 0.25, function()
									v:SetPos(0, orgy)
								end)
							end
						end
					end)
					
					button:AlphaTo(0, 0.5, 0)
					button2:AlphaTo(0, 0.5, 0)
					button3:AlphaTo(0, 0.5, 0)
				end
			end
			
			allpresets[prei - 1] = button
			return button
		end
		function generatepresets()
			allpresets = {}
			prei = 1
			if file.Exists("savedpresets.txt", "DATA") then
				local custom = file.Read("savedpresets.txt", "DATA") or "<Saved Presets failed to load!>,,Color:255 0 0 255\nCohesion:2\nAdhesion:0\nViscosity:100\nSurface Tension:\nFluid Rest Distance:"
				local yes = string.Split(custom, "nextpresetdefinder")
				table.ForEach(yes, function(i)
					local yest = string.Split(yes[i], "--")[1]
					local result = string.Split(yest, ",,")
					if yest ~= "" then
						scrollPanel:AddItem(createpreset("[Saved] " .. result[1], result[2], "yes2", yest))
					end
				end)
			end
			if file.Exists("importedpresets.txt", "DATA") then
				local custom = file.Read("importedpresets.txt", "DATA") or "<Imported Presets failed to load!>,,Color:255 0 0 255\nCohesion:2\nAdhesion:0\nViscosity:100\nSurface Tension:\nFluid Rest Distance:"
				local yes = string.Split(custom, "nextpresetdefinder")
				table.ForEach(yes, function(i)
					local yest = string.Split(yes[i], "--")[1]
					local result = string.Split(yest, ",,")
					if yest ~= "" then
						scrollPanel:AddItem(createpreset("[Imported] " .. result[1], result[2], "yes1", yest))
					end
				end)
			end
			if file.Exists("installedpresets.txt", "DATA") then
				local custom = file.Read("installedpresets.txt", "DATA") or "<Installed Presets failed to load!>,,Color:255 0 0 255\nCohesion:2\nAdhesion:0\nViscosity:100\nSurface Tension:\nFluid Rest Distance:"
				local yes = string.Split(custom, "nextpresetdefinder")
				table.ForEach(yes, function(i)
					local yest = string.Split(yes[i], "--")[1]
					local result = string.Split(yest, ",,")
					if yest ~= "" then
						scrollPanel:AddItem(createpreset("[Downloaded] " .. result[1], result[2], "yes", yest))
					end
				end)
			end
			local custom = file.Read("gwater2_custompresets.txt", "LUA") or "<Custom Presets failed to load!>,,Color:255 0 0 255\nCohesion:2\nAdhesion:0\nViscosity:100\nSurface Tension:\nFluid Rest Distance:"
			local yes = string.Split(custom, "\n")
			table.ForEach(yes, function(i)
				local yest = string.Split(yes[i], "--")[1]
				local result = string.Split(yest, ",,")
				if yest ~= "" then
					scrollPanel:AddItem(createpreset("[Custom] " .. result[1], result[2], "nope", yest))
				end
			end)
			scrollPanel:AddItem(createpreset("(Default) Water", "Color:\nCohesion:\nAdhesion:\nViscosity:\nSurface Tension:\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Acid", "Color:240 255 0 150\nCohesion:\nAdhesion:0.1\nViscosity:0\nSurface Tension:\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Blue Bouncy B A L L S", "Color:0 127 255 255\nCohesion:50\nAdhesion:0\nViscosity:0\nSurface Tension:5\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Blue Gel", "Color:0 127 255 255\nCohesion:50\nAdhesion:0\nViscosity:100\nSurface Tension:0\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Blood", "Color:240 0 0 250\nCohesion:0.45\nAdhesion:0.15\nViscosity:1\nSurface Tension:0\nFluid Rest Distance:0.55"))	-- Parameters by GHM
			scrollPanel:AddItem(createpreset("Glue", "Color:230 230 230 255\nCohesion:0.03\nAdhesion:0.1\nViscosity:10\nSurface Tension:\nFluid Rest Distance:"))	-- yeah sure.. "glue"...
			scrollPanel:AddItem(createpreset("Lava", "Color:255 210 0 200\nCohesion:0.1\nAdhesion:0.01\nViscosity:10\nSurface Tension:\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Oil", "Color:0 0 0 255\nCohesion:0\nAdhesion:0\nViscosity:0\nSurface Tension:0\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Goop", "Color:170 240 140 50\nCohesion:0.1\nAdhesion:0.1\nViscosity:10\nSurface Tension:0.25\nFluid Rest Distance:"))

			scrollPanel:AddItem(createpreset("Portal Gel (Blue)", "Color:0 127 255 255\nCohesion:0.1\nAdhesion:0.3\nViscosity:10\nSurface Tension:0.5\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Portal Gel (Orange)", "Color:255 127 0 255\nCohesion:0.1\nAdhesion:0.3\nViscosity:10\nSurface Tension:0.5\nFluid Rest Distance:"))

			scrollPanel:AddItem(createpreset("Soapy Water", "Color:215 240 255 20\nCohesion:\nAdhesion:\nViscosity:\nSurface Tension:0.001\nFluid Rest Distance:\nDiffuse Threshold:30\nDiffuse Lifetime:20"))

			scrollPanel:AddItem(createpreset("Piss", "Color:255 255 0 254\nCohesion:\nAdhesion:\nViscosity:\nSurface Tension:\nFluid Rest Distance:"))
			scrollPanel:AddItem(createpreset("Hydrophobic Water", "Color:\nCohesion:\nAdhesion:0\nViscosity:\nSurface Tension:\nFluid Rest Distance:"))

			scrollPanel:AddItem(createpreset("Reflective Water", "Color:\nCohesion:\nAdhesion:\nViscosity:\nSurface Tension:\nFluid Rest Distance:\nReflectance: 0.9"))
			scrollPanel:AddItem(createpreset("Cheese Sauce", "Color:255 255 120 255\nCohesion:50\nAdhesion:\nViscosity:\nSurface Tension:\nFluid Rest Distance:\nReflectance: 0\nSwimFriction: 100"))
		end
		local savepreset = vgui.Create("DButton", scrollPanel)
		local buttonpressed2 = false
		function savepreset:Paint(w, h)
			if buttonpressed2 then
				surface.SetDrawColor(menubuttonshovered)
			elseif savepreset:IsHovered() then
				surface.SetDrawColor(menubuttonshovered)
			else
				surface.SetDrawColor(menubuttons)
			end
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
		savepreset:SetText("Save Preset")
		savepreset:SetSize(235 / 2.2,15)
		savepreset:SetPos(160 + (235 / 2), 8)
		local colornormal = Color(255,255,255,255)
		local colorhovered = Color(0,27,86)
		local colorpressed = Color(0,80,255,255)
		savepreset:SetTextColor(colornormal)
		function savepreset:OnMousePressed()
			local preset = createpreset2(sliders, options)
			local x, y = mainFrame:GetPos() x = x + 200 y = y + 100
			local frame = vgui.Create("DFrame", mainFrame)
			frame:SetSize(10000,10000)
			frame:SetPos(0,0)
			frame:SetTitle("gwater2 (v" .. version .. ")")
			frame:MakePopup()
			frame:SetBackgroundBlur(true)
			frame:SetScreenLock(true)
			function frame:Paint(w, h)
				-- Blur background
				render.UpdateScreenEffectTexture()
				render.BlurRenderTarget(render.GetScreenEffectTexture(), 5, 5, 1)
				render.SetRenderTarget()
				render.DrawScreenQuad()
			
				-- dark background around 2d water sim
				surface.SetDrawColor(menupopupbackground)
				surface.DrawRect(0, 0, w, h)
			
				-- main outline
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h)
			
				-- from testing it seems each particle is around 0.8kb so you could probably do some math to figure out the memory required and show it here
			
				draw.DrawText("Save Preset", "GWater2Title", ScrW() / 2, ScrH() / 2.1, color_white, TEXT_ALIGN_CENTER)
				draw.DrawText("Please Set Name", "DermaDefault", ScrW() / 2, ScrH() / 2, color_white, TEXT_ALIGN_CENTER)
			
			end
		
			local confirm = vgui.Create("DButton", frame)
			confirm:SetPos(ScrW() / 1.9, ScrH() / 1.8)
			confirm:SetText("")
			confirm:SetSize(20, 20)
			confirm:SetImage("icon16/accept.png")
			confirm.Paint = nil
			local name = vgui.Create("DTextEntry", frame)
			name:SetPos(ScrW() / 2.25, ScrH() / 1.9)
			name:SetText("")
			name:SetSize(200, 20)
			name:SetPaintBackground(false)
			name:SetTextColor(colornormal)
			name:SetCursorColor(colornormal)
			function name:PaintOver(w, h)
				if name:IsHovered() then
					surface.SetDrawColor(menubuttonshovered)
				else
					surface.SetDrawColor(menubuttons)
				end
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
			function confirm:DoClick() 
				file.Append("savedpresets.txt", "nextpresetdefinder" .. name:GetText() .. ",," .. createpreset2(sliders, options))
				for i, v in pairs(allpresets) do
					v:Remove()
				end
				allpresets = {}
				generatepresets()
				frame:Close()
				buttonpressed2 = false
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			end
		
			local deny = vgui.Create("DButton", frame)
			deny:SetPos(ScrW() / 2.1, ScrH() / 1.8)
			deny:SetText("")
			deny:SetSize(20, 20)
			deny:SetImage("icon16/cross.png")
			deny.Paint = nil
			function deny:DoClick() 
				frame:Close()
				buttonpressed2 = false
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			end
		
			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
		end
		function savepreset:OnMouseReleased()
			buttonpressed2 = false
		end

		local copypreset = vgui.Create("DButton", scrollPanel)

		copypreset:SetText("Import Preset")
		copypreset:SetSize(235 / 2.2,15)
		copypreset:SetPos(160, 8)
		function copypreset:Paint(w, h)
			if buttonpressed2 then
				surface.SetDrawColor(menubuttonshovered)
			elseif copypreset:IsHovered() then
				surface.SetDrawColor(menubuttonshovered)
			else
				surface.SetDrawColor(menubuttons)
			end
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
		local colornormal = Color(255,255,255,255)
		local colorhovered = Color(0,27,86)
		local colorpressed = Color(0,80,255,255)
		copypreset:SetTextColor(colornormal)
		function copypreset:OnMousePressed()
			local preset = createpreset2(sliders, options)
			local x, y = mainFrame:GetPos() x = x + 200 y = y + 100
			local frame = vgui.Create("DFrame", mainFrame)
			frame:SetSize(10000,10000)
			frame:SetPos(0,0)
			frame:SetTitle("gwater2 (v" .. version .. ")")
			frame:MakePopup()
			frame:SetBackgroundBlur(true)
			frame:SetScreenLock(true)
			function frame:Paint(w, h)
				-- Blur background
				render.UpdateScreenEffectTexture()
				render.BlurRenderTarget(render.GetScreenEffectTexture(), 5, 5, 1)
				render.SetRenderTarget()
				render.DrawScreenQuad()
			
				-- dark background around 2d water sim
				surface.SetDrawColor(menupopupbackground)
				surface.DrawRect(0, 0, w, h)
			
				-- main outline
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h)
			
				-- from testing it seems each particle is around 0.8kb so you could probably do some math to figure out the memory required and show it here
			
				draw.DrawText("Import Preset", "GWater2Title", ScrW() / 2, ScrH() / 2.1, color_white, TEXT_ALIGN_CENTER)
				draw.DrawText("Input Extension Preset Here", "DermaDefault", ScrW() / 2, ScrH() / 2, color_white, TEXT_ALIGN_CENTER)
			
			end
		
			local confirm = vgui.Create("DButton", frame)
			confirm:SetPos(ScrW() / 1.9, ScrH() / 1.8)
			confirm:SetText("")
			confirm:SetSize(20, 20)
			confirm:SetImage("icon16/accept.png")
			confirm.Paint = nil
			local name = vgui.Create("DTextEntry", frame)
			name:SetPos(ScrW() / 8.5, ScrH() / 1.9)
			name:SetText("")
			name:SetSize(1600, 20)
			name:SetPaintBackground(false)
			name:SetTextColor(colornormal)
			name:SetCursorColor(colornormal)
			function name:PaintOver(w, h)
				if name:IsHovered() then
					surface.SetDrawColor(menubuttonshovered)
				else
					surface.SetDrawColor(menubuttons)
				end
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
			function confirm:DoClick() 
				file.Append("importedpresets.txt", "nextpresetdefinder" .. name:GetText())
				for i, v in pairs(allpresets) do
					v:Remove()
				end
				allpresets = {}
				generatepresets()
				frame:Close()
				buttonpressed2 = false
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			end
		
			local deny = vgui.Create("DButton", frame)
			deny:SetPos(ScrW() / 2.1, ScrH() / 1.8)
			deny:SetText("")
			deny:SetSize(20, 20)
			deny:SetImage("icon16/cross.png")
			deny.Paint = nil
			function deny:DoClick() 
				frame:Close()
				buttonpressed2 = false
				EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			end
		
			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
		end
		function copypreset:OnMouseReleased()
			buttonpressed2 = false
		end

		generatepresets()
	end

	function extension_tab(tabs)
		local scrollPanel = vgui.Create("DScrollPanel", tabs)
		local scrollEditTab = tabs:AddSheet("Extension", scrollPanel, "extension/ico logo.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- parameters
		local labels = {}
		local label = create_label(scrollPanel, "Extension", "", 0, 625)
		local old = label.Paint
		label.Paint = function(self, x, y)
			old(self, x, y)
			explanation:SetText([[Info about the Extension mod
			
			Made by Jn]])
			explanation_header = "Extension"
		end

		label2 = vgui.Create("DLabel", scrollPanel)
		label2:SetPos(0, 0)
		label2:SetSize(383, 1000000000)
		label2:SetText([[Hello!












		Welcome to the Extension mod made by Jn
		Heres a list of things this mod changes:
		- A new particle limit confirm screen
		- Bigger limits on some sliders
		- Particle amount and other info in the corner
		- SOUNDS!!!!
		- Better water sound detection
		- A preview reset button
		Changelog: v1.50
		- Just removed the changelog at this point bc we have the website

		Have Fun!

		- Jn
		]])
		label2:SetColor(Color(255, 255, 255))
		label2:SetTextInset(5, 30)
		label2:SetWrap(true)
		label2:SetContentAlignment(7)	-- shove text in top left corner
		label2:SetFont("GWater2Param")
		local logo = vgui.Create("DImage", scrollPanel)
		logo:SetPos(5, 40)
		logo:SetSize(256, 256)
		logo:SetImage("extension/logo.png")
	end

	function extension_settings_tab(tabs)
		local scrollPanel = vgui.Create("DScrollPanel", tabs)
		local scrollEditTab = tabs:AddSheet("Extension Settings", scrollPanel, "extension/ico logo.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- parameters
		local labels = {}
		local label = create_label(scrollPanel, "Extension Settings", "Extra Settings", 0, 500)
		local old = label.Paint
		label.Paint = function(self, x, y)
			old(self, x, y)
			explanation:SetText([[Extra Settings you can do with the Extension mod
			
			Made by Jn]])
			explanation_header = "Extension Settings"
		end

		local soundeffect = vgui.Create("DComboBox", scrollPanel)
		soundeffect:SetPos(125, 50)
		soundeffect:SetSize(55, 20)
		soundeffect:SetText(GetConVar("gwater2_splashsound"):GetString())
		soundeffect:AddChoice("Normal")
		soundeffect:AddChoice("Not even a splash")
		soundeffect:AddChoice("Air")
		soundeffect:AddChoice("Glue")
		soundeffect:AddChoice("poison.ogg")

		function soundeffect:OnSelect(index, value, data)
			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			RunConsoleCommand("gwater2_splashsound", value)
		end

		function soundeffect:ApplySchemeSettings()
			soundeffect:SetFGColor(menutext)
		end

		function soundeffect:OnMenuOpened(pnl)
			EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
			for k, label in pairs(pnl:GetCanvas():GetChildren()) do
				function label:Paint(w, h)
					if self:IsHovered() then
						surface.SetDrawColor(0,80,255, 60)
						surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(menuoutline)
					surface.DrawOutlinedRect(5, h, w - 10, 0, 1)
				end
				label:SetTextColor(menutext)
			end
			function pnl:Paint(w, h)
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(menuoutline)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
		end

		function soundeffect:Paint(w, h)
			if soundeffect:IsMenuOpen() then
				surface.SetDrawColor(0, 80, 255, 60)
			else
				surface.SetDrawColor(0, 0, 0, 100)
			end
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(menuoutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end

		label2:SetColor(Color(255, 255, 255))
		label2:SetTextInset(5, 30)
		label2:SetWrap(true)
		label2:SetContentAlignment(7)	-- shove text in top left corner
		label2:SetFont("GWater2Param")
		local box = vgui.Create("DCheckBox", scrollPanel)
		box:SetPos(130, 75)
		box:SetSize(20, 20)
		local label5 = vgui.Create("DLabel", scrollPanel)
		label5:SetPos(10, 75)
		label5:SetSize(200, 20)
		label5:SetText("Deadly Liquid")
		label5:SetColor(Color(255, 255, 255))
		label5:SetFont("GWater2Param")
		local label1004 = vgui.Create("DLabel", scrollPanel)
		label1004:SetPos(10, 50)
		label1004:SetSize(2000, 20)
		label1004:SetText("Splash Sound       (other stuff included)")
		label1004:SetColor(Color(255, 255, 255))
		label1004:SetFont("GWater2Param")
	
		if GetConVar("gwater2_deadly"):GetString() == "1" then
			box:SetChecked(true)
		else
			box:SetChecked(false)
		end
		function box:OnChange(val)
			if val then
				RunConsoleCommand("gwater2_deadly", "1")
			else
				RunConsoleCommand("gwater2_deadly", "0")
			end
		end
		create_slider_convar(scrollPanel, 3, 100, "gwater2_reflectance", "Reflectivity", 0.666, -16, 16)
		create_slider_convar(scrollPanel, 0, 125, "gwater2_swimspeed", "Swim Speed", 2, -20, 100)
		create_slider_convar(scrollPanel, 0, 150, "gwater2_swimfriction", "Swim Friction", 1, 0, 100)
		create_slider_convar(scrollPanel, 0, 175, "gwater2_swimbuoyancy", "Swim Buoyancy", 0.5, 0, 100)
		create_slider_convar(scrollPanel, 2, 200, "gwater2_drowntime", "Drown Time", 4, 0, 10)
		create_slider_convar(scrollPanel, 0, 225, "gwater2_drownparticles", "Drown Particles", 60, 0, 200)
		create_slider_convar(scrollPanel, 2, 250, "gwater2_drowndamage", "Drown Damage", 0.25, 0, 200) --self, decimals, dock, convar, name, default, low, high, length

		box = vgui.Create("DCheckBox", scrollPanel)
		box:SetPos(130, 275)
		box:SetSize(20, 20)
		if GetConVar("gwater2_debug_normals"):GetString() == "1" then
			box:SetChecked(true)
		else
			box:SetChecked(false)
		end
		function box:OnChange(val)
			local con = GetConVar("gwater2_debug_normals")
			con:SetBool(val)
		end
		label5 = vgui.Create("DLabel", scrollPanel)
		label5:SetPos(10, 275)
		label5:SetSize(200, 20)
		label5:SetText("Debug Normals")
		label5:SetColor(menutext)
		label5:SetFont("GWater2Param")
		box = vgui.Create("DCheckBox", scrollPanel)
		box:SetPos(130, 300)
		box:SetSize(20, 20)
		if GetConVar("gwater2_liquidnormals"):GetString() == "1" then
			box:SetChecked(true)
		else
			box:SetChecked(false)
		end
		function box:OnChange(val)
			local con = GetConVar("gwater2_liquidnormals")
			con:SetBool(val)
		end
		label5 = vgui.Create("DLabel", scrollPanel)
		label5:SetPos(10, 300)
		label5:SetSize(200, 20)
		label5:SetText("Normal Liquid")
		label5:SetColor(Color(255, 255, 255))
		label5:SetFont("GWater2Param")

		create_slider_convar(scrollPanel, 0, 325, "gwater2_multiplyparticles", "Multiply Particles", 20, 0, 200)
		create_slider_convar(scrollPanel, 2, 350, "gwater2_multiplywalk", "Speed Multiply", 1, 0, 50)
		create_slider_convar(scrollPanel, 2, 375, "gwater2_multiplyjump", "Jump Multiply", 1, 0, 50) --self, decimals, dock, convar, name, default, low, high, length

	end

	function extension_presetstore(tabs)
		local scrollPanel = vgui.Create("DScrollPanel", tabs)
		local scrollEditTab = tabs:AddSheet("Preset Store", scrollPanel, "extension/ico logo.png").Tab
		scrollEditTab.Paint = draw_tabs

		-- parameters
		local labels = {}
		local label = create_label(scrollPanel, "Preset Store", "", 0, 625)
		local old = label.Paint
		label.Paint = function(self, x, y)
			old(self, x, y)
			explanation:SetText([[Download presets here!
			
			Made by Jn
			
			Powered by a custom server]])
			explanation_header = "Extension"
		end
		function addchoice(self, pos, name, creator, data, feutured, result2, i)
			local panel = vgui.Create("DPanel", self)
			panel:SetPos(10, pos + 30)
			panel:SetSize(365, 50)
			if feutured then
				function panel:Paint(w,h)
					surface.SetDrawColor(168, 157, 0, 50)
					surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(168, 157, 0)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			else
				function panel:Paint(w,h)
					surface.SetDrawColor(menulabelbackground)
					surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(menuoutline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			end
			local downloadbtn = vgui.Create("DButton", panel)
			if file.Exists("installedpresets.txt", "DATA") then
				if string.Replace(file.Read("installedpresets.txt", "DATA"), name .. ",," .. result2 .. ",," .. creator, "abababababbaa") == file.Read("installedpresets.txt", "DATA") then
					downloadbtn:SetEnabled(true)
					downloadbtn:SetText("Download")
					downloadbtn:SetPos(305, 0)
					downloadbtn:SetSize(60, 25)
					downloadbtn:SetTextColor(menutext)
				else
					downloadbtn:SetEnabled(false)
					downloadbtn:SetText("Already Downloaded!")
					downloadbtn:SetPos(245, 0)
					downloadbtn:SetSize(120, 25)
					downloadbtn:SetTextColor(Color(100, 100, 100))
				end
			else
				downloadbtn:SetEnabled(true)
				downloadbtn:SetText("Download")
				downloadbtn:SetPos(305, 0)
				downloadbtn:SetSize(60, 25)
				downloadbtn:SetTextColor(menutext)
			end

			if feutured then
				function downloadbtn:Paint(w,h)
					if downloadbtn:IsHovered() and downloadbtn:IsEnabled() then
						surface.SetDrawColor(168, 157, 0, 150)
						surface.DrawRect(0, 0, w, h)
					else
						surface.SetDrawColor(menulabelbackground)
						surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(menuoutline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			else
				function downloadbtn:Paint(w,h)
					if downloadbtn:IsHovered() and downloadbtn:IsEnabled() then
						surface.SetDrawColor(0, 74, 165, 150)
						surface.DrawRect(0, 0, w, h)
					else
						surface.SetDrawColor(menulabelbackground)
						surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(menuoutline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			end
			local namepn = vgui.Create("DLabel", panel)
			namepn:SetText(name)
			namepn:SetSize(1000,20)
			namepn:SetFont("GWater2Param")
			namepn:SetPos(3,0)
			local crnamepn = vgui.Create("DLabel", panel)
			crnamepn:SetText("by " .. creator)
			crnamepn:SetSize(1000,20)
			crnamepn:SetFont("GWater2Param")
			crnamepn:SetPos(3,30)
			crnamepn:SetColor(Color(100, 100, 100, 255))
			if feutured then
				local featuredtxt = vgui.Create("DLabel", panel)
				featuredtxt:SetText("Featured Preset")
				featuredtxt:SetSize(1000,20)
				featuredtxt:SetFont("GWater2Param")
				featuredtxt:SetPos(3,15)
				featuredtxt:SetColor(Color(255, 255, 0, 255))
			end
			function downloadbtn:DoClick()
				surface.PlaySound("buttons/button15.wav")
				file.Append("installedpresets.txt", "nextpresetdefinder" .. data)
				downloadbtn:SetEnabled(false)
				downloadbtn:SetText("Already Downloaded!")
				downloadbtn:SetPos(245, 0)
				downloadbtn:SetSize(120, 25)
				downloadbtn:SetTextColor(Color(100, 100, 100, 255))
			end
			label:SetSize(385, (i * 50) + 42)

			local previewbtn = vgui.Create("DButton", panel)

			previewbtn:SetEnabled(true)
			previewbtn:SetText("Preview")
			previewbtn:SetPos(305, 25)
			previewbtn:SetSize(60, 25)
			previewbtn:SetTextColor(menutext)
			
			if feutured then
				function previewbtn:Paint(w,h)
					if previewbtn:IsHovered() and previewbtn:IsEnabled() then
						surface.SetDrawColor(168, 157, 0, 150)
						surface.DrawRect(0, 0, w, h)
					else
						surface.SetDrawColor(menulabelbackground)
						surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(menuoutline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			else
				function previewbtn:Paint(w,h)
					if previewbtn:IsHovered() and previewbtn:IsEnabled() then
						surface.SetDrawColor(0, 74, 165, 150)
						surface.DrawRect(0, 0, w, h)
					else
						surface.SetDrawColor(menulabelbackground)
						surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(menuoutline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			end

			function previewbtn:DoClick()
				surface.PlaySound("buttons/button15.wav")
				
				parsepreset(string.Split(result2, "/"), sliders, options, data)
			end
		end

		local labelstart1 = vgui.Create("DLabel", label)
		labelstart1:SetText("Establishing Connection...")
		labelstart1:SetSize(385,20)
		labelstart1:SetFont("GWater2Param")
		labelstart1:SetPos(0,30)
		labelstart1:SetContentAlignment(5)
		labelstart1:SetColor(Color(255, 255, 255, 255))
		
		http.Post("http://gwater2.lavacrafter.net:5000/read", {},
			function( body, length, headers, code )
				local yes = string.Split(util.JSONToTable(body)["content"], "\n")
				labelstart1:Remove()
				table.ForEach(yes, function(i)
					local yest = string.Split(yes[i], "--")[1]
					local result = string.Split(yest, ",,")
					if yest ~= "" then
						local result4 = result[4] or "not ferieaifia<esjtgijsrz"
						local boolsucp, errorp = pcall(addchoice, scrollPanel, 0 + (i - 1) * 50, result[1], result[3] or "<error>", yes[i], string.Replace(result4, "1", "FEAUTEATJAETIAJETIJEAITJAET") ~= result4, result[2], i)
						if boolsucp and i == 1 then
							local copypreset = vgui.Create("DButton", scrollPanel)
							local buttonpressed = false
							function copypreset:Paint(w, h)
								if buttonpressed then
									surface.SetDrawColor(menubuttonshovered)
								elseif copypreset:IsHovered() then
									surface.SetDrawColor(menubuttonshovered)
								else
									surface.SetDrawColor(menubuttons)
								end
								surface.DrawRect(0, 0, w, h)
								surface.SetDrawColor(menuoutline)
								surface.DrawOutlinedRect(0, 0, w, h, 1)
							end
							copypreset:SetText("Publish Preset (reopen menu to see new preset)")
							copypreset:SetSize(235,15)
							copypreset:SetPos(140, 8)
							local colornormal = Color(255,255,255,255)
							local colorhovered = Color(0,27,86)
							local colorpressed = Color(0,80,255,255)
							copypreset:SetTextColor(colornormal)
							function copypreset:OnMousePressed()
								local preset = createpreset2(sliders, options)
								local x, y = mainFrame:GetPos() x = x + 200 y = y + 100
								local frame = vgui.Create("DFrame", mainFrame)
								frame:SetSize(10000,10000)
								frame:SetPos(0,0)
								frame:SetTitle("gwater2 (v" .. version .. ")")
								frame:MakePopup()
								frame:SetBackgroundBlur(true)
								frame:SetScreenLock(true)
								function frame:Paint(w, h)
									-- Blur background
									render.UpdateScreenEffectTexture()
									render.BlurRenderTarget(render.GetScreenEffectTexture(), 5, 5, 1)
									render.SetRenderTarget()
									render.DrawScreenQuad()
								
									-- dark background around 2d water sim
									surface.SetDrawColor(menupopupbackground)
									surface.DrawRect(0, 0, w, h)
								
									-- main outline
									surface.SetDrawColor(menuoutline)
									surface.DrawOutlinedRect(0, 0, w, h)
								
									-- from testing it seems each particle is around 0.8kb so you could probably do some math to figure out the memory required and show it here
								
									draw.DrawText("Publish Preset", "GWater2Title", ScrW() / 2, ScrH() / 2.1, color_white, TEXT_ALIGN_CENTER)
									draw.DrawText("Please Set Name", "DermaDefault", ScrW() / 2, ScrH() / 2, color_white, TEXT_ALIGN_CENTER)
								
								end
							
								local confirm = vgui.Create("DButton", frame)
								confirm:SetPos(ScrW() / 1.9, ScrH() / 1.8)
								confirm:SetText("")
								confirm:SetSize(20, 20)
								confirm:SetImage("icon16/accept.png")
								confirm.Paint = nil
								local name = vgui.Create("DTextEntry", frame)
								name:SetPos(ScrW() / 2.1, ScrH() / 1.9)
								name:SetText("")
								name:SetSize(100, 20)
								name:SetPaintBackground(false)
								name:SetTextColor(colornormal)
								name:SetCursorColor(colornormal)
								function name:PaintOver(w, h)
									if name:IsHovered() then
										surface.SetDrawColor(menubuttonshovered)
									else
										surface.SetDrawColor(menubuttons)
									end
									surface.DrawRect(0, 0, w, h)
									surface.SetDrawColor(menuoutline)
									surface.DrawOutlinedRect(0, 0, w, h, 1)
								end
								function confirm:DoClick() 
									local presettopublish = name:GetText() .. ",," .. preset .. ",," .. LocalPlayer():GetName()
									local labelstart1p = vgui.Create("DLabel", frame)
									labelstart1p:SetText("Getting Paste Contents...")
									labelstart1p:Dock( FILL )
									labelstart1p:SetContentAlignment(5)
									labelstart1p:SetSize(385,40)
									labelstart1p:SetFont("GWater2Param")
									labelstart1p:SetPos(0,100)
									labelstart1p:SetContentAlignment(5)
									labelstart1p:SetColor(Color(255, 255, 255, 255))
									http.Post("http://gwater2.lavacrafter.net:5000/add", {data = presettopublish},
										-- onSuccess function
										function( body, length, headers, code )
											frame:Close()
										end,
										-- onFailure function
										function( message )
											ErrorNoHalt(message)
										end
									
									)
									
									buttonpressed = false
									EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
								end
							
								local deny = vgui.Create("DButton", frame)
								deny:SetPos(ScrW() / 2.1, ScrH() / 1.8)
								deny:SetText("")
								deny:SetSize(20, 20)
								deny:SetImage("icon16/cross.png")
								deny.Paint = nil
								function deny:DoClick() 
									frame:Close()
									buttonpressed = false
									EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
								end
							
								EmitSound("buttons/button15.wav", Vector(), -2, CHAN_AUTO, 1, nil, nil, 100 )
							end
							function copypreset:OnMouseReleased()
								buttonpressed = false
							end
						end
					end
				end)
			end,
			function( message )
				local ERROR = vgui.Create("DLabel", label)
				ERROR:SetText("ERROR:" .. message)
				ERROR:SetSize(385,40)
				ERROR:SetFont("GWater2Param")
				ERROR:SetPos(0,30)
				ERROR:SetContentAlignment(5)
				ERROR:SetColor(Color(255, 0, 0, 255))
			end
		)
	end


    local tabs = vgui.Create("DPropertySheet", tabsFrame)
	tabs:Dock(FILL)
	function tabs:Paint(w, h)
		surface.SetDrawColor(0, 0, 0, 100)
		surface.DrawRect(0, 20, w, h - 20)
		surface.SetDrawColor(menuoutline)
		surface.DrawOutlinedRect(0, 20, w, h - 20, 1)
	
		--surface.SetSize(192, 365)
		--SetPos(603, 30)
	end

	-- we need to save the index the tab is in, and when the menu is reopened it will set to that tab
	-- we cant use a reference to an actual panel because it wont be valid the next time the menu is opened... so we use the index instead
	function tabs:OnActiveTabChanged(old, new)
		for k, v in ipairs(self.Items) do
			if v.Tab == new then
				options.tab:SetInt(k)
				break
			end
		end
	end

	-- explanation area creation
	explanation = create_explanation(tabsFrame)
	explanation_header = options.about_tab_text
	explanation:SetText(options.about_tab_text)
	explanation:SetPos(398, 28)
	function explanation:Paint(w, h)
		surface.SetDrawColor(menulabelbackground)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(menuoutline)
		surface.DrawOutlinedRect(0, 0, w, h)
		draw.DrawText(explanation_header, "GWater2Title", 6, 6, menusecondary, TEXT_ALIGN_LEFT)
		draw.DrawText(explanation_header, "GWater2Title", 5, 5, menuaccent, TEXT_ALIGN_LEFT)
	end

	-- create tabs in order
	about_tab(tabs)
	watergun_tab(tabs)
	parameter_tab(tabs)
	extension_presetpicker(tabs)
	extension_presetstore(tabs)
	visuals_tab(tabs)
	performance_tab(tabs)
	patron_tab(tabs)
	extension_tab(tabs)
	extension_settings_tab(tabs)

	tabs:SetActiveTab(tabs.Items[options.tab:GetInt()].Tab)
end)



-- closes menu if mouse presses on the outside
hook.Add("GUIMousePressed", "gwater2_menuclose", function(mouse_code, aim_vector)
	if !IsValid(mainFrame) then return end

	local x, y = gui.MouseX(), gui.MouseY()
	local frame_x, frame_y = mainFrame:GetPos()
	if x < frame_x or x > frame_x + mainFrame:GetWide() or y < frame_y or y > frame_y + mainFrame:GetTall() then
		mainFrame:Remove()
	end
end)

hook.Add("PopulateToolMenu", "gwater2_menu", function()
    spawnmenu.AddToolMenuOption("Utilities", "gwater2", "gwater2_menu", "Menu Options", "", "", function(panel)
		panel:ClearControls()
		panel:Button("Open Menu", "gwater2_menu")
        panel:KeyBinder("Menu Key", "gwater2_menukey")
	end)
end)

-- hate this
function OpenGW2Menu(ply, key)
	if key != options.menu_key:GetInt() or just_closed == true then return end
	RunConsoleCommand("gwater2_menu")
end

function CloseGW2Menu(ply, key)
	if key != options.menu_key:GetInt() then return end
	just_closed = false
end

-- shit breaks in singleplayer due to predicted hooks
if game.SinglePlayer() then return end

hook.Add("PlayerButtonDown", "gwater2_menu", OpenGW2Menu)
hook.Add("PlayerButtonUp", "gwater2_menu", CloseGW2Menu)