TOOL.Category = "GWater2"
TOOL.Name = "Cloth"
TOOL.Command		= nil
TOOL.ConfigName		= ""

TOOL.Information = {
	{ name = "left", stage = 1 },
}



function TOOL:GetPlacementPosition(tr)
	if not tr then tr = self:GetOwner():GetEyeTrace() end
	if not tr.Hit then return false end

	return (tr.HitPos + tr.HitNormal * (self:GetOwner():GetInfoNum(5, 1) + 1)), rotatedAng
end

if (CLIENT) then
	language.Add("Tool.cloth_spawner.name", "Cloth")
	language.Add("Tool.cloth_spawner.desc", "Creates Cloth")
	language.Add("Tool.cloth_spawner.left", "Left Click: Spawn Cloth")

	clothx = CreateClientConVar("clothx", "50", false, true, "no comment", 1, 400)
	clothy = CreateClientConVar("clothy", "50", false, true, "no comment", 1, 400)
	clothup = CreateClientConVar("clothup", "4", false, true, "no comment", 1, 1000)

	function TOOL.BuildCPanel(panel)
		panel:AddControl("label", {
			text = "Creates Cloth",
		})
		panel:NumSlider("Cloth X Size", "clothx", 1, 400, 1)
		panel:NumSlider("Cloth Y Size", "clothy", 1, 400, 1)
		panel:NumSlider("Cloth Height", "clothup", 1, 1000, 1)
	end


elseif (SERVER) then
	function TOOL:Deploy()
		self:SetStage(1)
	end

	function TOOL:LeftClick(trace)
			local ply = self:GetOwner()
			local hitpos = ply:GetEyeTrace().HitPos
			local pos = hitpos + Vector(0, 0, self:GetOwner():GetInfoNum("clothup", 4))
			if not pos then return false end

			gwater2.AddCloth(gwater2.quick_matrix(pos), Vector(self:GetOwner():GetInfoNum("clothx", 50), self:GetOwner():GetInfoNum("clothy", 50), 0)) -- translation, size, particle_data

		return true
	end
end