AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel( "models/hunter/blocks/cube05x05x05.mdl")
    local phys = self:GetPhysicsObject()
    if phys:IsValid() then
        phys:Wake()
    end
end