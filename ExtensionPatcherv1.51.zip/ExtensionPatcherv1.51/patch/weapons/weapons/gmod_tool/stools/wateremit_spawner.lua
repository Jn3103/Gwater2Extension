TOOL.Category = "GWater2"
TOOL.Name = "Water Emitter"
TOOL.Command		= nil
TOOL.ConfigName		= ""

TOOL.Information = {
	{ name = "left", stage = 1 },
	{ name = "reload", stage = 1 },
}



function TOOL:GetPlacementPosition(tr)
	if not tr then tr = self:GetOwner():GetEyeTrace() end
	if not tr.Hit then return false end

	return (tr.HitPos + tr.HitNormal * (self:GetOwner():GetInfoNum(5, 1) + 1)), rotatedAng
end

if (CLIENT) then
	language.Add("Tool.wateremit_spawner.name", "Water Emitter")
	language.Add("Tool.wateremit_spawner.desc", "Creates Water Emitters")
	language.Add("Tool.wateremit_spawner.left", "Spawn Emitter")
	language.Add("Tool.wateremit_spawner.reload", "Delete all emitters")
	wateremitheight = CreateClientConVar("wateremit_height", "4", false, true, "Sets the height of the emitter", 1, 250)
	wateremitxsize = CreateClientConVar("wateremit_xs", "3", false, true, "Sets X Size of the emitter", 1, 200)
	wateremitysize = CreateClientConVar("wateremit_ys", "3", false, true, "Sets Y Size of the emitter", 1, 200)
	wateremitzsize = CreateClientConVar("wateremit_zs", "3", false, true, "Sets Z Size of the emitter", 1, 200)
	wateremitxvel = CreateClientConVar("wateremit_xv", "0", false, true, "Sets X Vel of the emitter", -500, 500)
	wateremityvel = CreateClientConVar("wateremit_yv", "0", false, true, "Sets Y Vel of the emitter", -500, 500)
	wateremitzvel = CreateClientConVar("wateremit_zv", "0", false, true, "Sets Z Vel of the emitter", -500, 500)
	wateremitspace = CreateClientConVar("wateremit_space", "10", false, true, "Sets Spacing of the emitter", 1, 500)
	wateremitxsize = CreateClientConVar("wateremit_r", "0", false, true, "Sets X Size of the emitter", 1, 200)
	wateremitysize = CreateClientConVar("wateremit_g", "255", false, true, "Sets Y Size of the emitter", 1, 200)
	wateremitzsize = CreateClientConVar("wateremit_b", "0", false, true, "Sets Z Size of the emitter", 1, 200)
	wateremitxsize = CreateClientConVar("wateremit_a", "255", false, true, "Sets X Size of the emitter", 1, 200)

	function TOOL.BuildCPanel(panel)
		panel:AddControl("label", {
			text = "Creates Water Emitters",
		})
		--panel:NumSlider("Emitter Spacing", "wateremit_space", 1, 100, 10)
		panel:NumSlider("Emitter Height", "wateremit_height", 1, 250, 1)
		panel:NumSlider("Emitter X Size", "wateremit_xs", 1, 200, 1)
		panel:NumSlider("Emitter Y Size", "wateremit_ys", 1, 200, 1)
		panel:NumSlider("Emitter Z Size", "wateremit_zs", 1, 200, 1)
		panel:NumSlider("Emitter X Velocity", "wateremit_xv", -500, 500, 1)
		panel:NumSlider("Emitter Y Velocity", "wateremit_yv", -500, 500, 1)
		panel:NumSlider("Emitter Z Velocity", "wateremit_zv", -500, 500, 1)
		panel:NumSlider("Emitter Spacing", "wateremit_space", 1, 500, 1)
		local setto = panel:Button("Set Spacing to Radius")
		function setto:OnMousePressed()
			RunConsoleCommand("wateremit_space", tostring(gwater2.solver:GetParameter("radius")))
		end
		local colorpick = vgui.Create( "DColorMixer", Frame)
		colorpick:SetColor(Color(0,255,0,255))
		function colorpick:ValueChanged(new)
			RunConsoleCommand("wateremit_r", tostring(new["r"]))
			RunConsoleCommand("wateremit_g", tostring(new["g"]))
			RunConsoleCommand("wateremit_b", tostring(new["b"]))
			RunConsoleCommand("wateremit_a", tostring(new["a"]))
		end
		panel:AddItem(colorpick)
	end


elseif (SERVER) then
	function TOOL:Deploy()
		self:SetStage(1)
	end

	function TOOL:LeftClick(trace)
			local ply = self:GetOwner()
			local hitpos = ply:GetEyeTrace().HitPos
			local ent = ents.Create("water_emitter")
			local pos = hitpos + Vector(0, 0, self:GetOwner():GetInfoNum("wateremit_height", 100))
			if not pos then return false end

			ent:SetPos(pos)
			ent:Spawn()
			self:SetStage(1)

			cleanup.Add(self:GetOwner(), "props", ent)
        	undo.Create("Water Emitter")
        	    undo.AddEntity(ent)
            undo.SetPlayer(self:GetOwner())
        	undo.Finish()
		return true
	end
	function TOOL:Reload()
		for k, v in ipairs( ents.FindByClass( "water_emitter" ) ) do
			v:Remove()
		end
	end
end