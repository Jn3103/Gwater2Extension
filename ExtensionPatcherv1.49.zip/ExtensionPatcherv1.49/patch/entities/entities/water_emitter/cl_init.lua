include("shared.lua")
-- Client-side draw function for the entity
function ENT:Draw()
    local xsize = tonumber(GetConVar("wateremit_xs"):GetString())
    local ysize = tonumber(GetConVar("wateremit_ys"):GetString())
    local zsize = tonumber(GetConVar("wateremit_zs"):GetString())
    local space = tonumber(GetConVar("wateremit_space"):GetString())
    local angle = Angle()
    local size = Vector(xsize, ysize, zsize)
    local color = HSVToColor(CurTime() * 50 + self:GetCreationTime() * 50, 1, 1)
    local tsize = size * space / 2

    render.DrawWireframeBox(self:GetPos(), angle, -tsize, tsize, color , true)
end

function ENT:Think()
    if activesp then
        local xsize = tonumber(GetConVar("wateremit_xs"):GetString())
        local ysize = tonumber(GetConVar("wateremit_ys"):GetString())
        local zsize = tonumber(GetConVar("wateremit_zs"):GetString())
        local space = tonumber(GetConVar("wateremit_space"):GetString())
        local xvel = tonumber(GetConVar("wateremit_xv"):GetString())
        local yvel = tonumber(GetConVar("wateremit_yv"):GetString())
        local zvel = tonumber(GetConVar("wateremit_zv"):GetString())
        local angle = Angle()
        local size = Vector(xsize, ysize, zsize)
        local entityPos = self:GetPos()
    	gwater2.solver:AddCube(entityPos + VectorRand(-1, 1), Vector(xvel, yvel, zvel), size, space)
   	return true
    end
end