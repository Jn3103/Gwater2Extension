TOOL.Category = "GWater2"
TOOL.Name = "Water Pool"
TOOL.Command		= nil
TOOL.ConfigName		= ""

TOOL.Information = {
	{ name = "left", stage = 0 },
	{ name = "left2", stage = 1 },
}



function TOOL:GetPlacementPosition(tr)
	if not tr then tr = self:GetOwner():GetEyeTrace() end
	if not tr.Hit then return false end

	return (tr.HitPos + tr.HitNormal * (self:GetOwner():GetInfoNum(5, 1) + 1)), rotatedAng
end

if (CLIENT) then
	language.Add("Tool.wateremit_pool.name", "Pool Tool")
	language.Add("Tool.wateremit_pool.desc", "Fills a Cuboid with water based of two points")
	language.Add("tool.wateremit_pool.left", "Set First Point.")
	language.Add("tool.wateremit_pool.left2", "Set Second Point to create the Cuboid.")
	CreateConVar("wateremit_1x", "0", FCVAR_REPLICATED, "idk")
	CreateConVar("wateremit_1y", "0", FCVAR_REPLICATED, "idk")
	CreateConVar("wateremit_1z", "0", FCVAR_REPLICATED, "idk")
	CreateConVar("wateremit_2x", "0", FCVAR_REPLICATED, "idk")
	CreateConVar("wateremit_2y", "0", FCVAR_REPLICATED, "idk")
	CreateConVar("wateremit_2z", "0", FCVAR_REPLICATED, "idk")
	CreateConVar("wateremit_2z", "0", FCVAR_REPLICATED, "idk")
	CreateConVar("wateremit_spacemultiply", "1.5", FCVAR_REPLICATED, "idk")

	function TOOL.BuildCPanel(panel)
		panel:AddControl("label", {
			text = "Fills a Cuboid with water based of two points",
		})
		panel:NumSlider("Water Multiplier", "wateremit_spacemultiply", 0, 10, 1)
	end


elseif (SERVER) then
	function TOOL:Deploy()
		self:SetStage(0)
	end

	function TOOL:LeftClick(trace)
		if self:GetStage() == 0 then
			local ply = self:GetOwner()
			local hitpos = ply:GetEyeTrace().HitPos
			local tablehitpos = string.Split(tostring(hitpos), " ")
			RunConsoleCommand("wateremit_1x", tablehitpos[1])
			RunConsoleCommand("wateremit_1y", tablehitpos[2])
			RunConsoleCommand("wateremit_1z", tablehitpos[3])
			self:SetStage(1)
		else
			local ent = ents.Create("water_pool")
			local ply = self:GetOwner()
			local hitpos = ply:GetEyeTrace().HitPos
			local tablehitpos = string.Split(tostring(hitpos), " ")
			RunConsoleCommand("wateremit_2x", tablehitpos[1])
			RunConsoleCommand("wateremit_2y", tablehitpos[2])
			RunConsoleCommand("wateremit_2z", tablehitpos[3])
			local p1 = Vector(tonumber(GetConVar("wateremit_1x"):GetString()), tonumber(GetConVar("wateremit_1y"):GetString()), tonumber(GetConVar("wateremit_1z"):GetString()))
   			local p2 = Vector(tonumber(tablehitpos[1]), tonumber(tablehitpos[2]), tonumber(tablehitpos[3]))
			ent:SetPos(LerpVector(0.5, p1, p2))
			ent:Spawn()
			self:SetStage(0)
		end
		return true
	end
	function TOOL:Think()
		if self:GetStage() == 1 then
			local ent = ents.Create("water_preview")
			local ply = self:GetOwner()
			local hitpos = ply:GetEyeTrace().HitPos
			local tablehitpos = string.Split(tostring(hitpos), " ")
			RunConsoleCommand("wateremit_2x", tablehitpos[1])
			RunConsoleCommand("wateremit_2y", tablehitpos[2])
			RunConsoleCommand("wateremit_2z", tablehitpos[3])
			local p1 = Vector(tonumber(GetConVar("wateremit_1x"):GetString()), tonumber(GetConVar("wateremit_1y"):GetString()), tonumber(GetConVar("wateremit_1z"):GetString()))
   			local p2 = Vector(tonumber(tablehitpos[1]), tonumber(tablehitpos[2]), tonumber(tablehitpos[3]))
			ent:SetPos(LerpVector(0.5, p1, p2))
			ent:Spawn()
		end
	end
end