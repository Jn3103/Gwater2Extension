include("shared.lua")
-- Client-side draw function for the entity
function ENT:Draw()
    local p1 = Vector(tonumber(GetConVar("wateremit_1x"):GetString()), tonumber(GetConVar("wateremit_1y"):GetString()), tonumber(GetConVar("wateremit_1z"):GetString()))
    local p2 = Vector(tonumber(GetConVar("wateremit_2x"):GetString()), tonumber(GetConVar("wateremit_2y"):GetString()), tonumber(GetConVar("wateremit_2z"):GetString()))
    local min = p1 - self:GetPos()
    local max = p2 - self:GetPos()
    render.DrawWireframeBox(self:GetPos(), Angle(), min, max, Color(0,55 + math.abs(math.sin(CurTime() * 2.5)) * 200,0), false)
end