include("shared.lua")
-- Client-side draw function for the entity
function ENT:Draw()
    local p1 = Vector(tonumber(GetConVar("wateremit_1x"):GetString()), tonumber(GetConVar("wateremit_1y"):GetString()), tonumber(GetConVar("wateremit_1z"):GetString()))
    local p2 = Vector(tonumber(GetConVar("wateremit_2x"):GetString()), tonumber(GetConVar("wateremit_2y"):GetString()), tonumber(GetConVar("wateremit_2z"):GetString()))
    local min = p1 - self:GetPos()
    local max = p2 - self:GetPos()
    render.DrawWireframeBox(self:GetPos(), Angle(), min, max, Color(0,255,0,math.abs(math.Clamp(CurTime() - self:GetCreationTime(), 0, 1) - 1) * 255), false)
end

function ENT:Think()
    local division1 = tonumber(GetConVar("wateremit_spacemultiply"):GetString())
    local division2 = division1 * 2
    local p1 = Vector(tonumber(GetConVar("wateremit_1x"):GetString()), tonumber(GetConVar("wateremit_1y"):GetString()), tonumber(GetConVar("wateremit_1z"):GetString()))
    local s = p1 - self:GetPos()
    ssplit = string.Split(tostring(s), " ")
    local sabs = Vector(math.abs(tonumber(ssplit[1])) / gwater2.solver:GetParameter("radius") * division2, math.abs(tonumber(ssplit[2])) / gwater2.solver:GetParameter("radius") * division2, math.abs(tonumber(ssplit[3])) / gwater2.solver:GetParameter("radius") * division2)
    if self:GetCreationTime() + FrameTime() > CurTime() then
        gwater2.solver:AddCube(self:GetPos(), Vector(0,0,0), sabs, gwater2.solver:GetParameter("radius") / division1)
    end
   	return true
end