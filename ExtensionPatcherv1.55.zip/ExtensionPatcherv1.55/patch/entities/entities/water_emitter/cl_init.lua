include("shared.lua")
-- Client-side draw function for the entity
function ENT:Draw()
    local xsize = self:GetNWFloat("XSize", 3)
    local ysize = self:GetNWFloat("YSize", 3)
    local zsize = self:GetNWFloat("ZSize", 3)
    local space = tonumber(GetConVar("wateremit_space"):GetString())
    local angle = self:GetAngles()
    local vel = self:GetNWFloat("Velocity", 10)
    local size = Vector(xsize, ysize, zsize)
    local color = Color(tonumber(GetConVar("wateremit_r"):GetString()), tonumber(GetConVar("wateremit_g"):GetString()), tonumber(GetConVar("wateremit_b"):GetString()), tonumber(GetConVar("wateremit_a"):GetString()))
    local tsize = size * space / 2

    render.DrawWireframeBox(self:GetPos(), Angle(), -tsize, tsize, color , true)
    render.DrawWireframeBox(self:GetPos(), angle, Vector(10,10,10), -Vector(10,10,10), color , true)
    render.DrawLine(self:GetPos(), self:GetPos() + self:GetAngles():Forward() * vel, color, true)
end

function ENT:Think()
    if activesp then
        local xsize = self:GetNWFloat("XSize", 3)
        local ysize = self:GetNWFloat("YSize", 3)
        local zsize = self:GetNWFloat("ZSize", 3)
        local space = tonumber(GetConVar("wateremit_space"):GetString())
        local vel = self:GetNWFloat("Velocity", 0)
        local size = Vector(xsize, ysize, zsize)
        local entityPos = self:GetPos()
    	gwater2.solver:AddCube(entityPos + VectorRand(-1, 1),self:GetAngles():Forward() * vel , size, space)
   	return true
    end
end